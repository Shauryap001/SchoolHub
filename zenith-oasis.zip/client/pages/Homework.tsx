import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../components/ui/dialog";
import { Textarea } from "../components/ui/textarea";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import {
  ArrowLeft,
  BookOpen,
  Plus,
  Search,
  Filter,
  Calendar,
  Clock,
  CheckCircle,
  AlertCircle,
  FileText,
  Download,
  Eye,
  Edit,
  Trash2,
  TrendingUp,
  Users,
} from "lucide-react";
import { toast } from "sonner";

// Mock homework data
const mockHomework = [
  {
    id: '1',
    title: 'Mathematics Chapter 5 Problems',
    subject: 'Mathematics',
    class: '10',
    division: 'A',
    teacher: 'Mr. Smith',
    assignedDate: '2024-01-15',
    dueDate: '2024-01-22',
    totalStudents: 35,
    submitted: 28,
    pending: 7,
    status: 'active' as const,
    description: 'Complete exercises 1-20 from Chapter 5: Quadratic Equations',
    attachments: ['chapter5_problems.pdf'],
  },
  {
    id: '2',
    title: 'English Essay: Environmental Conservation',
    subject: 'English',
    class: '9',
    division: 'B',
    teacher: 'Ms. Johnson',
    assignedDate: '2024-01-10',
    dueDate: '2024-01-20',
    totalStudents: 32,
    submitted: 30,
    pending: 2,
    status: 'due_today' as const,
    description: 'Write a 500-word essay on environmental conservation',
    attachments: ['essay_guidelines.pdf'],
  },
  {
    id: '3',
    title: 'Science Lab Report: Chemical Reactions',
    subject: 'Science',
    class: '8',
    division: 'A',
    teacher: 'Dr. Brown',
    assignedDate: '2024-01-08',
    dueDate: '2024-01-18',
    totalStudents: 30,
    submitted: 25,
    pending: 5,
    status: 'overdue' as const,
    description: 'Complete the lab report on chemical reactions experiment',
    attachments: ['lab_template.docx'],
  },
  {
    id: '4',
    title: 'History Timeline Project',
    subject: 'History',
    class: '7',
    division: 'A',
    teacher: 'Mrs. Davis',
    assignedDate: '2024-01-05',
    dueDate: '2024-01-25',
    totalStudents: 28,
    submitted: 15,
    pending: 13,
    status: 'active' as const,
    description: 'Create a timeline of major historical events from 1900-1950',
    attachments: [],
  },
];

const subjects = ['All Subjects', 'Mathematics', 'English', 'Science', 'History', 'Geography', 'Physics', 'Chemistry', 'Biology'];
const classes = Array.from({ length: 10 }, (_, i) => String(i + 1));
const divisions = ['A', 'B', 'C', 'D'];

export default function Homework() {
  const [homework, setHomework] = useState(mockHomework);
  const [filteredHomework, setFilteredHomework] = useState(mockHomework);
  const [selectedSubject, setSelectedSubject] = useState('All Subjects');
  const [selectedClass, setSelectedClass] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddDialog, setShowAddDialog] = useState(false);

  const [newHomework, setNewHomework] = useState({
    title: '',
    subject: '',
    class: '',
    division: '',
    dueDate: '',
    description: '',
  });

  // Apply filters
  const applyFilters = () => {
    let filtered = homework;

    if (selectedSubject !== 'All Subjects') {
      filtered = filtered.filter(hw => hw.subject === selectedSubject);
    }

    if (selectedClass !== 'all') {
      filtered = filtered.filter(hw => hw.class === selectedClass);
    }

    if (selectedStatus !== 'all') {
      filtered = filtered.filter(hw => hw.status === selectedStatus);
    }

    if (searchTerm) {
      filtered = filtered.filter(hw =>
        hw.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        hw.teacher.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredHomework(filtered);
  };

  // Apply filters when dependencies change
  useState(() => {
    applyFilters();
  });

  const getStatusBadge = (status: string) => {
    const variants = {
      active: 'bg-primary/10 text-primary',
      due_today: 'bg-warning/10 text-warning',
      overdue: 'bg-destructive/10 text-destructive',
      completed: 'bg-success/10 text-success',
    };

    const icons = {
      active: Clock,
      due_today: AlertCircle,
      overdue: AlertCircle,
      completed: CheckCircle,
    };

    const Icon = icons[status as keyof typeof icons];
    const statusText = status.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());

    return (
      <Badge className={variants[status as keyof typeof variants]}>
        <Icon className="h-3 w-3 mr-1" />
        {statusText}
      </Badge>
    );
  };

  const handleAddHomework = () => {
    if (!newHomework.title || !newHomework.subject || !newHomework.class) {
      toast.error("Please fill in required fields");
      return;
    }

    const homework = {
      id: Date.now().toString(),
      ...newHomework,
      teacher: 'Current User',
      assignedDate: new Date().toISOString().split('T')[0],
      totalStudents: 35,
      submitted: 0,
      pending: 35,
      status: 'active' as const,
      attachments: [],
    };

    setHomework(prev => [...prev, homework]);
    setNewHomework({
      title: '',
      subject: '',
      class: '',
      division: '',
      dueDate: '',
      description: '',
    });
    setShowAddDialog(false);
    toast.success("Homework assigned successfully!");
  };

  const stats = {
    total: filteredHomework.length,
    totalAll: homework.length,
    active: homework.filter(hw => hw.status === 'active').length,
    overdue: homework.filter(hw => hw.status === 'overdue').length,
    dueToday: homework.filter(hw => hw.status === 'due_today').length,
    totalSubmissions: homework.reduce((sum, hw) => sum + hw.submitted, 0),
    totalPending: homework.reduce((sum, hw) => sum + hw.pending, 0),
  };

  const submissionRate = stats.totalSubmissions + stats.totalPending > 0 
    ? Math.round((stats.totalSubmissions / (stats.totalSubmissions + stats.totalPending)) * 100)
    : 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="sm" asChild>
            <Link to="/">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <BookOpen className="h-8 w-8 text-primary" />
              Homework & Assignment Oversight
            </h1>
            <p className="text-muted-foreground">Monitor assignments, submissions, and academic progress</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Post Notice
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Post Official Notice</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="title">Notice Title *</Label>
                    <Input
                      id="title"
                      value={newHomework.title}
                      onChange={(e) => setNewHomework(prev => ({...prev, title: e.target.value}))}
                      placeholder="Enter notice title"
                    />
                  </div>
                  <div>
                    <Label htmlFor="subject">Subject</Label>
                    <Select value={newHomework.subject} onValueChange={(value) => setNewHomework(prev => ({...prev, subject: value}))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select subject" />
                      </SelectTrigger>
                      <SelectContent>
                        {subjects.slice(1).map(subject => (
                          <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="class">Target Class</Label>
                    <Select value={newHomework.class} onValueChange={(value) => setNewHomework(prev => ({...prev, class: value}))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select class" />
                      </SelectTrigger>
                      <SelectContent>
                        {classes.map(cls => (
                          <SelectItem key={cls} value={cls}>Class {cls}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="deadline">Deadline</Label>
                    <Input
                      id="deadline"
                      type="date"
                      value={newHomework.dueDate}
                      onChange={(e) => setNewHomework(prev => ({...prev, dueDate: e.target.value}))}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="description">Notice Description</Label>
                  <Textarea
                    id="description"
                    value={newHomework.description}
                    onChange={(e) => setNewHomework(prev => ({...prev, description: e.target.value}))}
                    placeholder="Enter detailed notice description..."
                    rows={4}
                  />
                </div>
                <div className="flex gap-2">
                  <Button onClick={handleAddHomework}>Post Notice</Button>
                  <Button variant="outline" onClick={() => setShowAddDialog(false)}>Cancel</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Total Assignments</p>
                <p className="text-2xl font-bold">{stats.totalAll}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Active</p>
                <p className="text-2xl font-bold text-primary">{stats.active}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-warning" />
              <div>
                <p className="text-sm text-muted-foreground">Due Today</p>
                <p className="text-2xl font-bold text-warning">{stats.dueToday}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-destructive" />
              <div>
                <p className="text-sm text-muted-foreground">Overdue</p>
                <p className="text-2xl font-bold text-destructive">{stats.overdue}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-success" />
              <div>
                <p className="text-sm text-muted-foreground">Submitted</p>
                <p className="text-2xl font-bold text-success">{stats.totalSubmissions}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-info" />
              <div>
                <p className="text-sm text-muted-foreground">Submission Rate</p>
                <p className="text-2xl font-bold text-info">{submissionRate}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="submissions">Submission Tracking</TabsTrigger>
          <TabsTrigger value="analytics">Performance Analytics</TabsTrigger>
          <TabsTrigger value="notices">Official Notices</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Filters */}
          <Card>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                <div>
                  <Label>Subject</Label>
                  <Select value={selectedSubject} onValueChange={(value) => {setSelectedSubject(value); setTimeout(applyFilters, 0);}}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {subjects.map(subject => (
                        <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Class</Label>
                  <Select value={selectedClass} onValueChange={(value) => {setSelectedClass(value); setTimeout(applyFilters, 0);}}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Classes</SelectItem>
                      {classes.map(cls => (
                        <SelectItem key={cls} value={cls}>Class {cls}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Status</Label>
                  <Select value={selectedStatus} onValueChange={(value) => {setSelectedStatus(value); setTimeout(applyFilters, 0);}}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="due_today">Due Today</SelectItem>
                      <SelectItem value="overdue">Overdue</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="md:col-span-2">
                  <Label>Search</Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search assignments or teachers..."
                      value={searchTerm}
                      onChange={(e) => {setSearchTerm(e.target.value); setTimeout(applyFilters, 0);}}
                      className="pl-10"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Homework Table */}
          <Card>
            <CardHeader>
              <CardTitle>Assignment Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableCaption>
                  {filteredHomework.length} assignment{filteredHomework.length !== 1 ? 's' : ''} found
                </TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead>Assignment</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead>Class</TableHead>
                    <TableHead>Teacher</TableHead>
                    <TableHead>Due Date</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredHomework.map((hw) => (
                    <TableRow key={hw.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{hw.title}</p>
                          <p className="text-sm text-muted-foreground">
                            Assigned: {hw.assignedDate}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{hw.subject}</Badge>
                      </TableCell>
                      <TableCell>{hw.class}{hw.division}</TableCell>
                      <TableCell>{hw.teacher}</TableCell>
                      <TableCell>{hw.dueDate}</TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="flex justify-between text-sm">
                            <span>Submitted: {hw.submitted}</span>
                            <span>Pending: {hw.pending}</span>
                          </div>
                          <div className="w-full bg-muted rounded-full h-2">
                            <div 
                              className="bg-success h-2 rounded-full" 
                              style={{width: `${(hw.submitted / hw.totalStudents) * 100}%`}}
                            />
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(hw.status)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center gap-2 justify-end">
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="submissions" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Submission Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Detailed Submission Tracking</h3>
                <p className="text-muted-foreground mb-4">
                  Track individual student submissions and pending work
                </p>
                <div className="bg-muted/50 rounded-lg p-8">
                  <p className="text-sm text-muted-foreground">
                    Student-wise submission tracking interface would appear here
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Performance Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <TrendingUp className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Assignment Analytics</h3>
                <p className="text-muted-foreground mb-4">
                  View class performance trends and submission patterns
                </p>
                <div className="bg-muted/50 rounded-lg p-8">
                  <p className="text-sm text-muted-foreground">
                    Charts and analytics for assignment performance would appear here
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notices" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Official Notices</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 border-l-4 border-l-warning bg-warning/5 rounded">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="h-5 w-5 text-warning mt-0.5" />
                    <div>
                      <p className="font-medium">Homework Deadline Extension</p>
                      <p className="text-sm text-muted-foreground">
                        Mathematics Chapter 5 Problems deadline extended to January 25th due to school event.
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">Posted 2 hours ago</p>
                    </div>
                  </div>
                </div>
                <div className="p-4 border-l-4 border-l-info bg-info/5 rounded">
                  <div className="flex items-start gap-3">
                    <FileText className="h-5 w-5 text-info mt-0.5" />
                    <div>
                      <p className="font-medium">New Assignment Format Guidelines</p>
                      <p className="text-sm text-muted-foreground">
                        Updated guidelines for essay submissions. Please follow the new format for all future assignments.
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">Posted yesterday</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
