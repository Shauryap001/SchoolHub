import { PlaceholderPage } from "../components/PlaceholderPage";
import { Library } from "lucide-react";

export default function LibraryPage() {
  return (
    <PlaceholderPage
      title="Library Management"
      description="Manage books, track issues, and catalog resources"
      icon={Library}
      features={[
        "Book catalog and search",
        "Issue and return tracking",
        "Digital library resources",
        "Reading history and recommendations",
        "Fine and overdue management",
        "Inventory management",
        "Student reading analytics"
      ]}
    />
  );
}
