import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import {
  ArrowLeft,
  Bus,
  MapPin,
  Clock,
  Users,
  Navigation,
  Phone,
  AlertTriangle,
  CheckCircle,
  Search,
  RefreshCw,
  Route,
  UserCheck,
} from "lucide-react";

// Mock data
const buses = [
  {
    id: '1',
    number: 'BUS-001',
    route: 'Main Street Route',
    driver: 'John Smith',
    driverPhone: '+1-555-0123',
    capacity: 50,
    studentsOnboard: 42,
    status: 'on-route' as const,
    currentLocation: 'Near Central Park',
    nextStop: 'School Gate',
    estimatedArrival: '08:15 AM',
    latitude: 40.7829,
    longitude: -73.9654,
  },
  {
    id: '2',
    number: 'BUS-002',
    route: 'North Side Route',
    driver: 'Sarah Johnson',
    driverPhone: '+1-555-0124',
    capacity: 45,
    studentsOnboard: 38,
    status: 'at-stop' as const,
    currentLocation: 'Stop 3 - Oak Street',
    nextStop: 'Stop 4 - Pine Avenue',
    estimatedArrival: '08:20 AM',
    latitude: 40.7901,
    longitude: -73.9602,
  },
  {
    id: '3',
    number: 'BUS-003',
    route: 'South Side Route',
    driver: 'Mike Wilson',
    driverPhone: '+1-555-0125',
    capacity: 48,
    studentsOnboard: 45,
    status: 'delayed' as const,
    currentLocation: 'Traffic on Highway 101',
    nextStop: 'Stop 2 - Maple Road',
    estimatedArrival: '08:35 AM',
    latitude: 40.7505,
    longitude: -73.9934,
  },
  {
    id: '4',
    number: 'BUS-004',
    route: 'East Side Route',
    driver: 'Emily Davis',
    driverPhone: '+1-555-0126',
    capacity: 52,
    studentsOnboard: 48,
    status: 'completed' as const,
    currentLocation: 'School Parking',
    nextStop: 'Journey Complete',
    estimatedArrival: 'Arrived',
    latitude: 40.7614,
    longitude: -73.9776,
  },
];

const mockStudents = [
  { id: '1', name: 'Alex Johnson', class: '10A', busNumber: 'BUS-001', pickupTime: '07:45 AM', status: 'picked-up' as const },
  { id: '2', name: 'Emma Wilson', class: '10A', busNumber: 'BUS-001', pickupTime: '07:50 AM', status: 'picked-up' as const },
  { id: '3', name: 'Liam Brown', class: '9B', busNumber: 'BUS-002', pickupTime: '07:55 AM', status: 'waiting' as const },
  { id: '4', name: 'Olivia Davis', class: '9B', busNumber: 'BUS-002', pickupTime: '08:00 AM', status: 'picked-up' as const },
  { id: '5', name: 'Noah Garcia', class: '10B', busNumber: 'BUS-003', pickupTime: '07:40 AM', status: 'absent' as const },
  { id: '6', name: 'Sophia Miller', class: '10B', busNumber: 'BUS-003', pickupTime: '07:45 AM', status: 'picked-up' as const },
];

export default function Transport() {
  const [selectedBus, setSelectedBus] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [currentTime, setCurrentTime] = useState(new Date());

  // Update current time every minute
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  const filteredBuses = selectedBus === 'all' ? buses : buses.filter(bus => bus.id === selectedBus);
  const filteredStudents = mockStudents.filter(student =>
    student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    student.busNumber.includes(searchTerm)
  );

  const getStatusBadge = (status: string) => {
    const variants = {
      'on-route': 'bg-primary/10 text-primary',
      'at-stop': 'bg-info/10 text-info',
      'delayed': 'bg-warning/10 text-warning',
      'completed': 'bg-success/10 text-success',
      'picked-up': 'bg-success/10 text-success',
      'waiting': 'bg-warning/10 text-warning',
      'absent': 'bg-destructive/10 text-destructive',
    };
    
    const icons = {
      'on-route': Navigation,
      'at-stop': MapPin,
      'delayed': AlertTriangle,
      'completed': CheckCircle,
      'picked-up': UserCheck,
      'waiting': Clock,
      'absent': AlertTriangle,
    };

    const Icon = icons[status as keyof typeof icons];
    
    return (
      <Badge className={variants[status as keyof typeof variants]}>
        <Icon className="h-3 w-3 mr-1" />
        <span className="capitalize">{status.replace('-', ' ')}</span>
      </Badge>
    );
  };

  const stats = {
    totalBuses: buses.length,
    activeBuses: buses.filter(bus => bus.status !== 'completed').length,
    totalStudents: buses.reduce((sum, bus) => sum + bus.studentsOnboard, 0),
    delayedBuses: buses.filter(bus => bus.status === 'delayed').length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="sm" asChild>
            <Link to="/">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Bus className="h-8 w-8 text-primary" />
              Transport Tracker
            </h1>
            <p className="text-muted-foreground">Real-time bus tracking and transport management</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="text-right">
            <p className="text-sm text-muted-foreground">Current Time</p>
            <p className="font-semibold">{currentTime.toLocaleTimeString()}</p>
          </div>
          <Button variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Bus className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Total Buses</p>
                <p className="text-2xl font-bold">{stats.totalBuses}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Navigation className="h-5 w-5 text-success" />
              <div>
                <p className="text-sm text-muted-foreground">Active</p>
                <p className="text-2xl font-bold text-success">{stats.activeBuses}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-info" />
              <div>
                <p className="text-sm text-muted-foreground">Students</p>
                <p className="text-2xl font-bold text-info">{stats.totalStudents}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-warning" />
              <div>
                <p className="text-sm text-muted-foreground">Delayed</p>
                <p className="text-2xl font-bold text-warning">{stats.delayedBuses}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="live-tracking" className="space-y-6">
        <TabsList>
          <TabsTrigger value="live-tracking">Live Tracking</TabsTrigger>
          <TabsTrigger value="students">Student Status</TabsTrigger>
          <TabsTrigger value="routes">Routes</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
        </TabsList>

        <TabsContent value="live-tracking" className="space-y-6">
          {/* Controls */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="flex-1">
                  <label className="text-sm font-medium mb-2 block">Filter by Bus</label>
                  <Select value={selectedBus} onValueChange={setSelectedBus}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Buses</SelectItem>
                      {buses.map(bus => (
                        <SelectItem key={bus.id} value={bus.id}>
                          {bus.number} - {bus.route}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Live Tracking */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Bus List */}
            <Card>
              <CardHeader>
                <CardTitle>Bus Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {filteredBuses.map(bus => (
                  <div key={bus.id} className="p-4 border rounded-lg space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Bus className="h-5 w-5 text-primary" />
                        <div>
                          <p className="font-semibold">{bus.number}</p>
                          <p className="text-sm text-muted-foreground">{bus.route}</p>
                        </div>
                      </div>
                      {getStatusBadge(bus.status)}
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Driver</p>
                        <p className="font-medium">{bus.driver}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Students</p>
                        <p className="font-medium">{bus.studentsOnboard}/{bus.capacity}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Current Location</p>
                        <p className="font-medium">{bus.currentLocation}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">ETA</p>
                        <p className="font-medium">{bus.estimatedArrival}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm">
                        <MapPin className="h-4 w-4 mr-2" />
                        Track on Map
                      </Button>
                      <Button variant="outline" size="sm">
                        <Phone className="h-4 w-4 mr-2" />
                        Call Driver
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Map View */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  Live Map View
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="aspect-square bg-muted rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Interactive Map</h3>
                    <p className="text-muted-foreground mb-4">
                      Real-time bus locations would be displayed here
                    </p>
                    <div className="space-y-2">
                      {buses.map(bus => (
                        <div key={bus.id} className="flex items-center justify-between p-2 bg-background rounded border">
                          <span className="text-sm">{bus.number}</span>
                          <div className="flex items-center gap-2">
                            <div className={`h-2 w-2 rounded-full ${
                              bus.status === 'on-route' ? 'bg-primary' :
                              bus.status === 'at-stop' ? 'bg-info' :
                              bus.status === 'delayed' ? 'bg-warning' :
                              'bg-success'
                            }`} />
                            <span className="text-xs text-muted-foreground">
                              {bus.currentLocation}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="students" className="space-y-6">
          {/* Search */}
          <Card>
            <CardContent className="p-6">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search students by name or bus number"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </CardContent>
          </Card>

          {/* Student List */}
          <Card>
            <CardHeader>
              <CardTitle>Student Transport Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {filteredStudents.map(student => (
                  <div key={student.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <span className="text-sm font-medium text-primary">
                          {student.name.split(' ').map(n => n[0]).join('')}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium">{student.name}</p>
                        <p className="text-sm text-muted-foreground">
                          Class: {student.class} | Bus: {student.busNumber} | Pickup: {student.pickupTime}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      {getStatusBadge(student.status)}
                      <Button variant="outline" size="sm">
                        <MapPin className="h-4 w-4 mr-2" />
                        Track Bus
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="routes" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Route className="h-5 w-5" />
                Bus Routes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {buses.map(bus => (
                  <div key={bus.id} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h3 className="font-semibold">{bus.number} - {bus.route}</h3>
                        <p className="text-sm text-muted-foreground">Driver: {bus.driver}</p>
                      </div>
                      <Badge variant="outline">
                        {bus.studentsOnboard} students
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Route optimization and stop details would be displayed here
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Transport Notifications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 border-l-4 border-l-warning bg-warning/5 rounded">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-warning mt-0.5" />
                    <div>
                      <p className="font-medium">Bus BUS-003 Delayed</p>
                      <p className="text-sm text-muted-foreground">
                        Expected delay of 15 minutes due to traffic on Highway 101
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">2 minutes ago</p>
                    </div>
                  </div>
                </div>
                <div className="p-4 border-l-4 border-l-success bg-success/5 rounded">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-success mt-0.5" />
                    <div>
                      <p className="font-medium">Bus BUS-004 Arrived</p>
                      <p className="text-sm text-muted-foreground">
                        Successfully arrived at school with 48 students
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">5 minutes ago</p>
                    </div>
                  </div>
                </div>
                <div className="p-4 border-l-4 border-l-info bg-info/5 rounded">
                  <div className="flex items-start gap-3">
                    <MapPin className="h-5 w-5 text-info mt-0.5" />
                    <div>
                      <p className="font-medium">Bus BUS-002 at Stop</p>
                      <p className="text-sm text-muted-foreground">
                        Currently at Stop 3 - Oak Street, picking up students
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">3 minutes ago</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
