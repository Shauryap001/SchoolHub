import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import {
  ArrowLeft,
  FileText,
  Plus,
  Search,
  Download,
  Upload,
  Edit,
  Eye,
  TrendingUp,
  BarChart3,
  PieChart,
  Award,
  Target,
  Users,
  BookOpen,
} from "lucide-react";
import { toast } from "sonner";

// Mock grades data
const mockGrades = [
  {
    id: '1',
    studentId: '1',
    studentName: 'Alex Johnson',
    class: '10A',
    subject: 'Mathematics',
    examType: 'Mid-Term',
    maxMarks: 100,
    obtainedMarks: 85,
    grade: 'B+',
    remarks: 'Good performance',
    date: '2024-01-15',
    teacher: 'Mr. Smith',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Alex',
  },
  {
    id: '2',
    studentId: '1',
    studentName: 'Alex Johnson',
    class: '10A',
    subject: 'English',
    examType: 'Mid-Term',
    maxMarks: 100,
    obtainedMarks: 92,
    grade: 'A',
    remarks: 'Excellent work',
    date: '2024-01-15',
    teacher: 'Ms. Johnson',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Alex',
  },
  {
    id: '3',
    studentId: '2',
    studentName: 'Emma Wilson',
    class: '10A',
    subject: 'Mathematics',
    examType: 'Mid-Term',
    maxMarks: 100,
    obtainedMarks: 78,
    grade: 'B',
    remarks: 'Can improve',
    date: '2024-01-15',
    teacher: 'Mr. Smith',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Emma',
  },
  {
    id: '4',
    studentId: '3',
    studentName: 'Liam Brown',
    class: '9B',
    subject: 'Science',
    examType: 'Unit Test',
    maxMarks: 50,
    obtainedMarks: 45,
    grade: 'A',
    remarks: 'Outstanding',
    date: '2024-01-10',
    teacher: 'Dr. Brown',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Liam',
  },
];

const mockStudents = [
  {
    id: '1',
    name: 'Alex Johnson',
    class: '10A',
    rollNo: 'A001',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Alex',
    totalMarks: 850,
    obtainedMarks: 765,
    percentage: 90.0,
    rank: 1,
    grade: 'A+',
  },
  {
    id: '2',
    name: 'Emma Wilson',
    class: '10A',
    rollNo: 'A002',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Emma',
    totalMarks: 850,
    obtainedMarks: 731,
    percentage: 86.0,
    rank: 2,
    grade: 'A',
  },
  {
    id: '3',
    name: 'Liam Brown',
    class: '9B',
    rollNo: 'B001',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Liam',
    totalMarks: 750,
    obtainedMarks: 645,
    percentage: 86.0,
    rank: 1,
    grade: 'A',
  },
];

const subjects = ['Mathematics', 'English', 'Science', 'History', 'Geography', 'Physics', 'Chemistry', 'Biology'];
const classes = ['10A', '10B', '9A', '9B', '8A', '8B'];
const examTypes = ['Mid-Term', 'Final-Term', 'Unit Test', 'Monthly Test', 'Internal Assessment'];

export default function Results() {
  const [grades, setGrades] = useState(mockGrades);
  const [filteredGrades, setFilteredGrades] = useState(mockGrades);
  const [selectedClass, setSelectedClass] = useState('all');
  const [selectedSubject, setSelectedSubject] = useState('all');
  const [selectedExamType, setSelectedExamType] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddDialog, setShowAddDialog] = useState(false);

  const [newGrade, setNewGrade] = useState({
    studentName: '',
    class: '',
    subject: '',
    examType: '',
    maxMarks: '',
    obtainedMarks: '',
    remarks: '',
  });

  // Apply filters
  const applyFilters = () => {
    let filtered = grades;

    if (selectedClass !== 'all') {
      filtered = filtered.filter(grade => grade.class === selectedClass);
    }

    if (selectedSubject !== 'all') {
      filtered = filtered.filter(grade => grade.subject === selectedSubject);
    }

    if (selectedExamType !== 'all') {
      filtered = filtered.filter(grade => grade.examType === selectedExamType);
    }

    if (searchTerm) {
      filtered = filtered.filter(grade =>
        grade.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        grade.teacher.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredGrades(filtered);
  };

  // Apply filters when dependencies change
  useState(() => {
    applyFilters();
  });

  const calculateGrade = (obtained: number, max: number) => {
    const percentage = (obtained / max) * 100;
    if (percentage >= 95) return 'A+';
    if (percentage >= 85) return 'A';
    if (percentage >= 75) return 'B+';
    if (percentage >= 65) return 'B';
    if (percentage >= 55) return 'C+';
    if (percentage >= 45) return 'C';
    if (percentage >= 35) return 'D';
    return 'F';
  };

  const handleAddGrade = () => {
    if (!newGrade.studentName || !newGrade.class || !newGrade.subject || !newGrade.maxMarks || !newGrade.obtainedMarks) {
      toast.error("Please fill in required fields");
      return;
    }

    const maxMarks = parseInt(newGrade.maxMarks);
    const obtainedMarks = parseInt(newGrade.obtainedMarks);

    const grade = {
      id: Date.now().toString(),
      studentId: Date.now().toString(),
      studentName: newGrade.studentName,
      class: newGrade.class,
      subject: newGrade.subject,
      examType: newGrade.examType,
      maxMarks,
      obtainedMarks,
      grade: calculateGrade(obtainedMarks, maxMarks),
      remarks: newGrade.remarks,
      date: new Date().toISOString().split('T')[0],
      teacher: 'Current User',
      profileImage: `https://api.dicebear.com/7.x/initials/svg?seed=${newGrade.studentName}`,
    };

    setGrades(prev => [...prev, grade]);
    setNewGrade({
      studentName: '',
      class: '',
      subject: '',
      examType: '',
      maxMarks: '',
      obtainedMarks: '',
      remarks: '',
    });
    setShowAddDialog(false);
    toast.success("Grade added successfully!");
  };

  const generateReportCard = (studentId: string) => {
    toast.success("Report card generated successfully!");
  };

  const getGradeBadgeColor = (grade: string) => {
    switch (grade) {
      case 'A+': case 'A': return 'bg-success/10 text-success';
      case 'B+': case 'B': return 'bg-primary/10 text-primary';
      case 'C+': case 'C': return 'bg-warning/10 text-warning';
      case 'D': case 'F': return 'bg-destructive/10 text-destructive';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const stats = {
    totalGrades: grades.length,
    averageScore: grades.length > 0 ? Math.round(grades.reduce((sum, grade) => sum + (grade.obtainedMarks / grade.maxMarks) * 100, 0) / grades.length) : 0,
    totalStudents: new Set(grades.map(g => g.studentId)).size,
    passRate: grades.length > 0 ? Math.round((grades.filter(g => (g.obtainedMarks / g.maxMarks) * 100 >= 35).length / grades.length) * 100) : 0,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="sm" asChild>
            <Link to="/">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <FileText className="h-8 w-8 text-primary" />
              Grading & Results Management
            </h1>
            <p className="text-muted-foreground">Manage exam scores, grades, and generate report cards</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Upload className="h-4 w-4 mr-2" />
            Import Grades
          </Button>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export Results
          </Button>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Total Grades</p>
                <p className="text-2xl font-bold">{stats.totalGrades}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Target className="h-5 w-5 text-success" />
              <div>
                <p className="text-sm text-muted-foreground">Average Score</p>
                <p className="text-2xl font-bold text-success">{stats.averageScore}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-info" />
              <div>
                <p className="text-sm text-muted-foreground">Students</p>
                <p className="text-2xl font-bold text-info">{stats.totalStudents}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Award className="h-5 w-5 text-warning" />
              <div>
                <p className="text-sm text-muted-foreground">Pass Rate</p>
                <p className="text-2xl font-bold text-warning">{stats.passRate}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="grades" className="space-y-6">
        <TabsList>
          <TabsTrigger value="grades">Grade Entry</TabsTrigger>
          <TabsTrigger value="reports">Report Cards</TabsTrigger>
          <TabsTrigger value="analytics">Performance Analytics</TabsTrigger>
          <TabsTrigger value="rankings">Class Rankings</TabsTrigger>
        </TabsList>

        <TabsContent value="grades" className="space-y-6">
          {/* Filters & Add Grade */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4 flex-1">
                  <div>
                    <Label>Class</Label>
                    <Select value={selectedClass} onValueChange={(value) => {setSelectedClass(value); setTimeout(applyFilters, 0);}}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Classes</SelectItem>
                        {classes.map(cls => (
                          <SelectItem key={cls} value={cls}>{cls}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Subject</Label>
                    <Select value={selectedSubject} onValueChange={(value) => {setSelectedSubject(value); setTimeout(applyFilters, 0);}}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Subjects</SelectItem>
                        {subjects.map(subject => (
                          <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Exam Type</Label>
                    <Select value={selectedExamType} onValueChange={(value) => {setSelectedExamType(value); setTimeout(applyFilters, 0);}}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Exams</SelectItem>
                        {examTypes.map(type => (
                          <SelectItem key={type} value={type}>{type}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="md:col-span-2">
                    <Label>Search</Label>
                    <div className="relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search students or teachers..."
                        value={searchTerm}
                        onChange={(e) => {setSearchTerm(e.target.value); setTimeout(applyFilters, 0);}}
                        className="pl-10"
                      />
                    </div>
                  </div>
                </div>
                <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
                  <DialogTrigger asChild>
                    <Button className="ml-4">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Grade
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New Grade</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Student Name *</Label>
                          <Input
                            value={newGrade.studentName}
                            onChange={(e) => setNewGrade(prev => ({...prev, studentName: e.target.value}))}
                            placeholder="Enter student name"
                          />
                        </div>
                        <div>
                          <Label>Class *</Label>
                          <Select value={newGrade.class} onValueChange={(value) => setNewGrade(prev => ({...prev, class: value}))}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select class" />
                            </SelectTrigger>
                            <SelectContent>
                              {classes.map(cls => (
                                <SelectItem key={cls} value={cls}>{cls}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Subject *</Label>
                          <Select value={newGrade.subject} onValueChange={(value) => setNewGrade(prev => ({...prev, subject: value}))}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select subject" />
                            </SelectTrigger>
                            <SelectContent>
                              {subjects.map(subject => (
                                <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Exam Type *</Label>
                          <Select value={newGrade.examType} onValueChange={(value) => setNewGrade(prev => ({...prev, examType: value}))}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select exam type" />
                            </SelectTrigger>
                            <SelectContent>
                              {examTypes.map(type => (
                                <SelectItem key={type} value={type}>{type}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Max Marks *</Label>
                          <Input
                            type="number"
                            value={newGrade.maxMarks}
                            onChange={(e) => setNewGrade(prev => ({...prev, maxMarks: e.target.value}))}
                            placeholder="100"
                          />
                        </div>
                        <div>
                          <Label>Obtained Marks *</Label>
                          <Input
                            type="number"
                            value={newGrade.obtainedMarks}
                            onChange={(e) => setNewGrade(prev => ({...prev, obtainedMarks: e.target.value}))}
                            placeholder="85"
                          />
                        </div>
                        <div className="col-span-2">
                          <Label>Remarks</Label>
                          <Input
                            value={newGrade.remarks}
                            onChange={(e) => setNewGrade(prev => ({...prev, remarks: e.target.value}))}
                            placeholder="Enter remarks (optional)"
                          />
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button onClick={handleAddGrade}>Add Grade</Button>
                        <Button variant="outline" onClick={() => setShowAddDialog(false)}>Cancel</Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardContent>
          </Card>

          {/* Grades Table */}
          <Card>
            <CardHeader>
              <CardTitle>Grade Records</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableCaption>
                  {filteredGrades.length} grade record{filteredGrades.length !== 1 ? 's' : ''} found
                </TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Class</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead>Exam Type</TableHead>
                    <TableHead>Marks</TableHead>
                    <TableHead>Grade</TableHead>
                    <TableHead>Teacher</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredGrades.map((grade) => (
                    <TableRow key={grade.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={grade.profileImage} alt={grade.studentName} />
                            <AvatarFallback>
                              {grade.studentName.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{grade.studentName}</p>
                            <p className="text-sm text-muted-foreground">{grade.date}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{grade.class}</Badge>
                      </TableCell>
                      <TableCell>{grade.subject}</TableCell>
                      <TableCell>{grade.examType}</TableCell>
                      <TableCell>
                        <div>
                          <span className="font-medium">{grade.obtainedMarks}/{grade.maxMarks}</span>
                          <span className="text-sm text-muted-foreground ml-2">
                            ({Math.round((grade.obtainedMarks / grade.maxMarks) * 100)}%)
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getGradeBadgeColor(grade.grade)}>
                          {grade.grade}
                        </Badge>
                      </TableCell>
                      <TableCell>{grade.teacher}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center gap-2 justify-end">
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Student Report Cards</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableCaption>{mockStudents.length} student{mockStudents.length !== 1 ? 's' : ''} available</TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Class</TableHead>
                    <TableHead>Roll No</TableHead>
                    <TableHead>Total Marks</TableHead>
                    <TableHead>Percentage</TableHead>
                    <TableHead>Grade</TableHead>
                    <TableHead>Rank</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockStudents.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={student.profileImage} alt={student.name} />
                            <AvatarFallback>
                              {student.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <span className="font-medium">{student.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{student.class}</Badge>
                      </TableCell>
                      <TableCell>{student.rollNo}</TableCell>
                      <TableCell>{student.obtainedMarks}/{student.totalMarks}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{student.percentage}%</span>
                          <div className="w-16 bg-muted rounded-full h-2">
                            <div 
                              className="bg-success h-2 rounded-full" 
                              style={{width: `${student.percentage}%`}}
                            />
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getGradeBadgeColor(student.grade)}>
                          {student.grade}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">#{student.rank}</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center gap-2 justify-end">
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4 mr-2" />
                            View Report
                          </Button>
                          <Button 
                            size="sm"
                            onClick={() => generateReportCard(student.id)}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Download PDF
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Subject Performance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Performance Charts</h3>
                  <p className="text-muted-foreground">
                    Subject-wise performance analytics would appear here
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="h-5 w-5" />
                  Grade Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <PieChart className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Grade Distribution</h3>
                  <p className="text-muted-foreground">
                    Grade distribution charts would appear here
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Performance Trends
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <TrendingUp className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Trend Analysis</h3>
                  <p className="text-muted-foreground">
                    Performance trend analysis would appear here
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Class Comparison
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Target className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Class Comparison</h3>
                  <p className="text-muted-foreground">
                    Inter-class performance comparison would appear here
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="rankings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Class Rankings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {classes.map(className => (
                  <Card key={className}>
                    <CardHeader>
                      <CardTitle className="text-lg">{className} Rankings</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {mockStudents
                          .filter(student => student.class === className)
                          .sort((a, b) => a.rank - b.rank)
                          .map(student => (
                            <div key={student.id} className="flex items-center justify-between p-3 border rounded-lg">
                              <div className="flex items-center gap-3">
                                <Badge variant="outline" className="w-8 h-8 rounded-full flex items-center justify-center">
                                  #{student.rank}
                                </Badge>
                                <Avatar className="h-8 w-8">
                                  <AvatarImage src={student.profileImage} alt={student.name} />
                                  <AvatarFallback>
                                    {student.name.split(' ').map(n => n[0]).join('')}
                                  </AvatarFallback>
                                </Avatar>
                                <div>
                                  <p className="font-medium">{student.name}</p>
                                  <p className="text-sm text-muted-foreground">Roll No: {student.rollNo}</p>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="font-semibold">{student.percentage}%</p>
                                <Badge className={getGradeBadgeColor(student.grade)}>
                                  {student.grade}
                                </Badge>
                              </div>
                            </div>
                          ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
