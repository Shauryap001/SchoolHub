import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../components/ui/dialog";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import {
  ArrowLeft,
  Calendar,
  Plus,
  Download,
  Printer,
  Edit,
  Trash2,
  Clock,
  AlertTriangle,
  CheckCircle,
  BookOpen,
  Users,
  CalendarDays,
  School,
} from "lucide-react";
import { toast } from "sonner";

// Mock timetable data
const timeSlots = [
  '08:00 - 08:45',
  '08:45 - 09:30',
  '09:30 - 10:15',
  '10:15 - 10:30', // Break
  '10:30 - 11:15',
  '11:15 - 12:00',
  '12:00 - 12:45',
  '12:45 - 01:30', // Lunch
  '01:30 - 02:15',
  '02:15 - 03:00',
  '03:00 - 03:45',
];

const weekDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

const mockTimetable = {
  '10A': {
    Monday: {
      '08:00 - 08:45': { subject: 'Mathematics', teacher: 'Mr. Smith', room: 'R101' },
      '08:45 - 09:30': { subject: 'English', teacher: 'Ms. Johnson', room: 'R102' },
      '09:30 - 10:15': { subject: 'Science', teacher: 'Dr. Brown', room: 'Lab1' },
      '10:15 - 10:30': { subject: 'Break', teacher: '', room: '' },
      '10:30 - 11:15': { subject: 'History', teacher: 'Mrs. Davis', room: 'R103' },
      '11:15 - 12:00': { subject: 'Geography', teacher: 'Mr. Wilson', room: 'R104' },
      '12:00 - 12:45': { subject: 'Physical Education', teacher: 'Coach Miller', room: 'Gym' },
      '12:45 - 01:30': { subject: 'Lunch Break', teacher: '', room: '' },
      '01:30 - 02:15': { subject: 'Art', teacher: 'Ms. Garcia', room: 'Art Room' },
      '02:15 - 03:00': { subject: 'Music', teacher: 'Mr. Taylor', room: 'Music Room' },
      '03:00 - 03:45': { subject: 'Computer Science', teacher: 'Ms. Anderson', room: 'Computer Lab' },
    },
    Tuesday: {
      '08:00 - 08:45': { subject: 'Science', teacher: 'Dr. Brown', room: 'Lab1' },
      '08:45 - 09:30': { subject: 'Mathematics', teacher: 'Mr. Smith', room: 'R101' },
      '09:30 - 10:15': { subject: 'English', teacher: 'Ms. Johnson', room: 'R102' },
      '10:15 - 10:30': { subject: 'Break', teacher: '', room: '' },
      '10:30 - 11:15': { subject: 'Geography', teacher: 'Mr. Wilson', room: 'R104' },
      '11:15 - 12:00': { subject: 'History', teacher: 'Mrs. Davis', room: 'R103' },
      '12:00 - 12:45': { subject: 'Mathematics', teacher: 'Mr. Smith', room: 'R101' },
      '12:45 - 01:30': { subject: 'Lunch Break', teacher: '', room: '' },
      '01:30 - 02:15': { subject: 'Physical Education', teacher: 'Coach Miller', room: 'Gym' },
      '02:15 - 03:00': { subject: 'Computer Science', teacher: 'Ms. Anderson', room: 'Computer Lab' },
      '03:00 - 03:45': { subject: 'Library', teacher: 'Ms. White', room: 'Library' },
    },
    // Add more days as needed
  }
};

const mockExams = [
  {
    id: '1',
    title: 'Mid-Term Examination',
    class: '10A',
    subject: 'Mathematics',
    date: '2024-02-15',
    time: '09:00 - 12:00',
    room: 'Exam Hall A',
    teacher: 'Mr. Smith',
    duration: '3 hours',
    status: 'scheduled' as const,
  },
  {
    id: '2',
    title: 'Unit Test',
    class: '9B',
    subject: 'Science',
    date: '2024-02-10',
    time: '10:00 - 11:30',
    room: 'R101',
    teacher: 'Dr. Brown',
    duration: '1.5 hours',
    status: 'completed' as const,
  },
  {
    id: '3',
    title: 'Final Examination',
    class: '8A',
    subject: 'English',
    date: '2024-03-20',
    time: '09:00 - 12:00',
    room: 'Exam Hall B',
    teacher: 'Ms. Johnson',
    duration: '3 hours',
    status: 'scheduled' as const,
  },
];

const conflicts = [
  {
    id: '1',
    type: 'teacher_double_booking',
    description: 'Mr. Smith is scheduled for both 10A and 9B at 10:30 AM on Monday',
    severity: 'high' as const,
    affected: ['10A Mathematics', '9B Physics'],
  },
  {
    id: '2',
    type: 'room_conflict',
    description: 'Room R101 is booked for both Mathematics and Science at 2:00 PM on Tuesday',
    severity: 'medium' as const,
    affected: ['10A Mathematics', '8B Science'],
  },
];

const classes = ['10A', '10B', '9A', '9B', '8A', '8B'];
const subjects = ['Mathematics', 'English', 'Science', 'History', 'Geography', 'Physical Education', 'Art', 'Music', 'Computer Science'];
const teachers = ['Mr. Smith', 'Ms. Johnson', 'Dr. Brown', 'Mrs. Davis', 'Mr. Wilson', 'Coach Miller', 'Ms. Garcia', 'Mr. Taylor', 'Ms. Anderson'];

export default function Timetable() {
  const [selectedClass, setSelectedClass] = useState('10A');
  const [selectedWeek, setSelectedWeek] = useState('current');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showExamDialog, setShowExamDialog] = useState(false);
  const [activeTab, setActiveTab] = useState('timetable');

  const [newEntry, setNewEntry] = useState({
    day: '',
    timeSlot: '',
    subject: '',
    teacher: '',
    room: '',
  });

  const [newExam, setNewExam] = useState({
    title: '',
    class: '',
    subject: '',
    date: '',
    time: '',
    room: '',
    teacher: '',
    duration: '',
  });

  const handleAddEntry = () => {
    if (!newEntry.day || !newEntry.timeSlot || !newEntry.subject) {
      toast.error("Please fill in required fields");
      return;
    }

    // Mock adding to timetable
    toast.success("Timetable entry added successfully!");
    setNewEntry({
      day: '',
      timeSlot: '',
      subject: '',
      teacher: '',
      room: '',
    });
    setShowAddDialog(false);
  };

  const handleAddExam = () => {
    if (!newExam.title || !newExam.class || !newExam.subject) {
      toast.error("Please fill in required fields");
      return;
    }

    toast.success("Exam scheduled successfully!");
    setNewExam({
      title: '',
      class: '',
      subject: '',
      date: '',
      time: '',
      room: '',
      teacher: '',
      duration: '',
    });
    setShowExamDialog(false);
  };

  const exportTimetable = () => {
    toast.success("Timetable exported successfully!");
  };

  const printTimetable = () => {
    window.print();
    toast.success("Printing timetable...");
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      scheduled: 'bg-primary/10 text-primary',
      completed: 'bg-success/10 text-success',
      cancelled: 'bg-destructive/10 text-destructive',
    };

    return (
      <Badge className={variants[status as keyof typeof variants]}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'text-destructive';
      case 'medium': return 'text-warning';
      case 'low': return 'text-info';
      default: return 'text-muted-foreground';
    }
  };

  const currentTimetable = mockTimetable[selectedClass as keyof typeof mockTimetable] || {};

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="sm" asChild>
            <Link to="/">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Calendar className="h-8 w-8 text-primary" />
              Timetable & Scheduling Management
            </h1>
            <p className="text-muted-foreground">Create and manage class schedules and exam timetables</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={exportTimetable}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button variant="outline" onClick={printTimetable}>
            <Printer className="h-4 w-4 mr-2" />
            Print
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <School className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Active Classes</p>
                <p className="text-2xl font-bold">{classes.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-success" />
              <div>
                <p className="text-sm text-muted-foreground">Subjects</p>
                <p className="text-2xl font-bold">{subjects.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-info" />
              <div>
                <p className="text-sm text-muted-foreground">Teachers</p>
                <p className="text-2xl font-bold">{teachers.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-warning" />
              <div>
                <p className="text-sm text-muted-foreground">Conflicts</p>
                <p className="text-2xl font-bold text-warning">{conflicts.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList>
          <TabsTrigger value="timetable">Weekly Timetable</TabsTrigger>
          <TabsTrigger value="exams">Exam Schedules</TabsTrigger>
          <TabsTrigger value="conflicts">Conflicts & Warnings</TabsTrigger>
          <TabsTrigger value="management">Schedule Management</TabsTrigger>
        </TabsList>

        <TabsContent value="timetable" className="space-y-6">
          {/* Controls */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div>
                    <Label>Select Class</Label>
                    <Select value={selectedClass} onValueChange={setSelectedClass}>
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {classes.map(cls => (
                          <SelectItem key={cls} value={cls}>{cls}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Week</Label>
                    <Select value={selectedWeek} onValueChange={setSelectedWeek}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="current">Current Week</SelectItem>
                        <SelectItem value="next">Next Week</SelectItem>
                        <SelectItem value="custom">Custom Range</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="h-4 w-4 mr-2" />
                      Add Entry
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Timetable Entry</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Day</Label>
                          <Select value={newEntry.day} onValueChange={(value) => setNewEntry(prev => ({...prev, day: value}))}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select day" />
                            </SelectTrigger>
                            <SelectContent>
                              {weekDays.map(day => (
                                <SelectItem key={day} value={day}>{day}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Time Slot</Label>
                          <Select value={newEntry.timeSlot} onValueChange={(value) => setNewEntry(prev => ({...prev, timeSlot: value}))}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select time" />
                            </SelectTrigger>
                            <SelectContent>
                              {timeSlots.map(slot => (
                                <SelectItem key={slot} value={slot}>{slot}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Subject</Label>
                          <Select value={newEntry.subject} onValueChange={(value) => setNewEntry(prev => ({...prev, subject: value}))}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select subject" />
                            </SelectTrigger>
                            <SelectContent>
                              {subjects.map(subject => (
                                <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Teacher</Label>
                          <Select value={newEntry.teacher} onValueChange={(value) => setNewEntry(prev => ({...prev, teacher: value}))}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select teacher" />
                            </SelectTrigger>
                            <SelectContent>
                              {teachers.map(teacher => (
                                <SelectItem key={teacher} value={teacher}>{teacher}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="col-span-2">
                          <Label>Room</Label>
                          <Input
                            value={newEntry.room}
                            onChange={(e) => setNewEntry(prev => ({...prev, room: e.target.value}))}
                            placeholder="Enter room number"
                          />
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button onClick={handleAddEntry}>Add Entry</Button>
                        <Button variant="outline" onClick={() => setShowAddDialog(false)}>Cancel</Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardContent>
          </Card>

          {/* Timetable Grid */}
          <Card>
            <CardHeader>
              <CardTitle>Weekly Timetable - {selectedClass}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-32">Time</TableHead>
                      {weekDays.map(day => (
                        <TableHead key={day} className="text-center min-w-32">{day}</TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {timeSlots.map(slot => (
                      <TableRow key={slot}>
                        <TableCell className="font-medium">{slot}</TableCell>
                        {weekDays.map(day => {
                          const entry = currentTimetable[day]?.[slot];
                          const isBreak = slot.includes('10:15 - 10:30') || slot.includes('12:45 - 01:30');
                          
                          return (
                            <TableCell key={`${day}-${slot}`} className="text-center">
                              {isBreak ? (
                                <div className="p-2 bg-muted/50 rounded text-sm text-muted-foreground">
                                  {entry?.subject || 'Break'}
                                </div>
                              ) : entry ? (
                                <div className="p-2 bg-primary/5 border border-primary/10 rounded">
                                  <div className="font-medium text-sm">{entry.subject}</div>
                                  <div className="text-xs text-muted-foreground">{entry.teacher}</div>
                                  <div className="text-xs text-muted-foreground">{entry.room}</div>
                                </div>
                              ) : (
                                <div className="p-2 border-2 border-dashed border-muted rounded text-xs text-muted-foreground">
                                  Free Period
                                </div>
                              )}
                            </TableCell>
                          );
                        })}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="exams" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">Exam Schedules</h2>
            <Dialog open={showExamDialog} onOpenChange={setShowExamDialog}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Schedule Exam
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Schedule New Exam</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2">
                      <Label>Exam Title</Label>
                      <Input
                        value={newExam.title}
                        onChange={(e) => setNewExam(prev => ({...prev, title: e.target.value}))}
                        placeholder="Enter exam title"
                      />
                    </div>
                    <div>
                      <Label>Class</Label>
                      <Select value={newExam.class} onValueChange={(value) => setNewExam(prev => ({...prev, class: value}))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select class" />
                        </SelectTrigger>
                        <SelectContent>
                          {classes.map(cls => (
                            <SelectItem key={cls} value={cls}>{cls}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Subject</Label>
                      <Select value={newExam.subject} onValueChange={(value) => setNewExam(prev => ({...prev, subject: value}))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select subject" />
                        </SelectTrigger>
                        <SelectContent>
                          {subjects.map(subject => (
                            <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Date</Label>
                      <Input
                        type="date"
                        value={newExam.date}
                        onChange={(e) => setNewExam(prev => ({...prev, date: e.target.value}))}
                      />
                    </div>
                    <div>
                      <Label>Time</Label>
                      <Input
                        value={newExam.time}
                        onChange={(e) => setNewExam(prev => ({...prev, time: e.target.value}))}
                        placeholder="09:00 - 12:00"
                      />
                    </div>
                    <div>
                      <Label>Room</Label>
                      <Input
                        value={newExam.room}
                        onChange={(e) => setNewExam(prev => ({...prev, room: e.target.value}))}
                        placeholder="Exam Hall A"
                      />
                    </div>
                    <div>
                      <Label>Duration</Label>
                      <Input
                        value={newExam.duration}
                        onChange={(e) => setNewExam(prev => ({...prev, duration: e.target.value}))}
                        placeholder="3 hours"
                      />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={handleAddExam}>Schedule Exam</Button>
                    <Button variant="outline" onClick={() => setShowExamDialog(false)}>Cancel</Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <Card>
            <CardContent>
              <Table>
                <TableCaption>{mockExams.length} exam{mockExams.length !== 1 ? 's' : ''} scheduled</TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead>Exam</TableHead>
                    <TableHead>Class</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead>Date & Time</TableHead>
                    <TableHead>Room</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockExams.map((exam) => (
                    <TableRow key={exam.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{exam.title}</p>
                          <p className="text-sm text-muted-foreground">{exam.teacher}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{exam.class}</Badge>
                      </TableCell>
                      <TableCell>{exam.subject}</TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{exam.date}</p>
                          <p className="text-sm text-muted-foreground">{exam.time}</p>
                        </div>
                      </TableCell>
                      <TableCell>{exam.room}</TableCell>
                      <TableCell>{exam.duration}</TableCell>
                      <TableCell>{getStatusBadge(exam.status)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center gap-2 justify-end">
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="conflicts" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-warning" />
                Schedule Conflicts & Warnings
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {conflicts.map((conflict) => (
                  <div key={conflict.id} className={`p-4 border-l-4 rounded ${
                    conflict.severity === 'high' ? 'border-l-destructive bg-destructive/5' :
                    conflict.severity === 'medium' ? 'border-l-warning bg-warning/5' :
                    'border-l-info bg-info/5'
                  }`}>
                    <div className="flex items-start justify-between">
                      <div>
                        <p className={`font-medium ${getSeverityColor(conflict.severity)}`}>
                          {conflict.type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                        </p>
                        <p className="text-sm text-muted-foreground mt-1">
                          {conflict.description}
                        </p>
                        <div className="flex gap-2 mt-2">
                          {conflict.affected.map((item, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {item}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <Button variant="outline" size="sm">
                        Resolve
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="management" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Schedule Management Tools</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card>
                  <CardContent className="p-6 text-center">
                    <CalendarDays className="h-12 w-12 text-primary mx-auto mb-4" />
                    <h3 className="font-semibold mb-2">Bulk Schedule Import</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Import timetables from CSV or Excel files
                    </p>
                    <Button variant="outline" className="w-full">
                      Import Schedule
                    </Button>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6 text-center">
                    <Users className="h-12 w-12 text-success mx-auto mb-4" />
                    <h3 className="font-semibold mb-2">Teacher Assignments</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Manage teacher-subject assignments
                    </p>
                    <Button variant="outline" className="w-full">
                      Manage Teachers
                    </Button>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6 text-center">
                    <School className="h-12 w-12 text-info mx-auto mb-4" />
                    <h3 className="font-semibold mb-2">Room Management</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Configure classrooms and facilities
                    </p>
                    <Button variant="outline" className="w-full">
                      Manage Rooms
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
