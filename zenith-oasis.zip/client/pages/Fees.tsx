import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../components/ui/dialog";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import {
  ArrowLeft,
  CreditCard,
  Users,
  CheckCircle,
  XCircle,
  Search,
  Download,
  Calendar,
  DollarSign,
  AlertCircle,
  Clock,
  Eye,
  Receipt,
  Send,
} from "lucide-react";

// Mock data
const feeCategories = [
  { id: '1', name: 'Tuition Fee', amount: 15000, dueDate: '2025-01-15' },
  { id: '2', name: 'Transport Fee', amount: 3000, dueDate: '2025-01-15' },
  { id: '3', name: 'Library Fee', amount: 500, dueDate: '2025-01-15' },
  { id: '4', name: 'Lab Fee', amount: 2000, dueDate: '2025-01-15' },
  { id: '5', name: 'Sports Fee', amount: 1000, dueDate: '2025-01-15' },
];

const mockStudents = [
  { 
    id: '1', 
    name: 'John Doe', 
    class: '10A', 
    rollNo: '001', 
    totalFees: 21500, 
    paidAmount: 18500,
    pendingAmount: 3000,
    status: 'partial' as const,
    lastPayment: '2024-12-15',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=John'
  },
  { 
    id: '2', 
    name: 'Jane Smith', 
    class: '10A', 
    rollNo: '002', 
    totalFees: 21500, 
    paidAmount: 21500,
    pendingAmount: 0,
    status: 'paid' as const,
    lastPayment: '2024-12-20',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Jane'
  },
  { 
    id: '3', 
    name: 'Mike Johnson', 
    class: '10A', 
    rollNo: '003', 
    totalFees: 21500, 
    paidAmount: 0,
    pendingAmount: 21500,
    status: 'pending' as const,
    lastPayment: null,
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Mike'
  },
  { 
    id: '4', 
    name: 'Sarah Wilson', 
    class: '10A', 
    rollNo: '004', 
    totalFees: 21500, 
    paidAmount: 10000,
    pendingAmount: 11500,
    status: 'overdue' as const,
    lastPayment: '2024-11-15',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Sarah'
  },
];

const paymentMethods = [
  { id: 'card', name: 'Credit/Debit Card', icon: CreditCard },
  { id: 'upi', name: 'UPI Payment', icon: CreditCard },
  { id: 'netbanking', name: 'Net Banking', icon: CreditCard },
  { id: 'wallet', name: 'Digital Wallet', icon: CreditCard },
];

export default function Fees() {
  const [selectedClass, setSelectedClass] = useState('10A');
  const [students, setStudents] = useState(mockStudents);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<typeof mockStudents[0] | null>(null);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [selectedMethod, setSelectedMethod] = useState('');
  const [paymentRemark, setPaymentRemark] = useState('');

  const filteredStudents = students.filter(student =>
    student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    student.rollNo.includes(searchTerm) ||
    student.class.includes(selectedClass)
  );

  const getStatusBadge = (status: string) => {
    const variants = {
      paid: 'bg-success/10 text-success',
      partial: 'bg-warning/10 text-warning',
      pending: 'bg-info/10 text-info',
      overdue: 'bg-destructive/10 text-destructive',
    };
    
    const icons = {
      paid: CheckCircle,
      partial: Clock,
      pending: AlertCircle,
      overdue: XCircle,
    };

    const Icon = icons[status as keyof typeof icons];
    
    return (
      <Badge className={variants[status as keyof typeof variants]}>
        <Icon className="h-3 w-3 mr-1" />
        <span className="capitalize">{status}</span>
      </Badge>
    );
  };

  const handlePayment = () => {
    if (!selectedStudent || !paymentAmount || !selectedMethod) return;
    
    // Mock payment processing
    const amount = parseInt(paymentAmount);
    setStudents(prev => prev.map(student => {
      if (student.id === selectedStudent.id) {
        const newPaidAmount = student.paidAmount + amount;
        const newPendingAmount = student.totalFees - newPaidAmount;
        const newStatus = newPendingAmount <= 0 ? 'paid' : 'partial';
        
        return {
          ...student,
          paidAmount: newPaidAmount,
          pendingAmount: Math.max(0, newPendingAmount),
          status: newStatus,
          lastPayment: new Date().toISOString().split('T')[0],
        };
      }
      return student;
    }));
    
    // Reset form
    setPaymentAmount('');
    setSelectedMethod('');
    setPaymentRemark('');
    setSelectedStudent(null);
  };

  const stats = {
    total: filteredStudents.reduce((sum, student) => sum + student.totalFees, 0),
    collected: filteredStudents.reduce((sum, student) => sum + student.paidAmount, 0),
    pending: filteredStudents.reduce((sum, student) => sum + student.pendingAmount, 0),
    students: filteredStudents.length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="sm" asChild>
            <Link to="/">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <CreditCard className="h-8 w-8 text-primary" />
              Fees & Payments
            </h1>
            <p className="text-muted-foreground">Manage fee collection and payment tracking</p>
          </div>
        </div>
        <Button>
          <Download className="h-4 w-4 mr-2" />
          Export Report
        </Button>
      </div>

      {/* Controls */}
      <Card>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Class</label>
              <Select value={selectedClass} onValueChange={setSelectedClass}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10A">Class 10A</SelectItem>
                  <SelectItem value="10B">Class 10B</SelectItem>
                  <SelectItem value="9A">Class 9A</SelectItem>
                  <SelectItem value="9B">Class 9B</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Search Students</label>
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by name or roll number"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex items-end">
              <Button className="w-full">
                <Send className="h-4 w-4 mr-2" />
                Send Reminders
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="payments">Make Payment</TabsTrigger>
          <TabsTrigger value="history">Payment History</TabsTrigger>
          <TabsTrigger value="structure">Fee Structure</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Total Fees</p>
                    <p className="text-2xl font-bold">₹{stats.total.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-success" />
                  <div>
                    <p className="text-sm text-muted-foreground">Collected</p>
                    <p className="text-2xl font-bold text-success">₹{stats.collected.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <AlertCircle className="h-5 w-5 text-warning" />
                  <div>
                    <p className="text-sm text-muted-foreground">Pending</p>
                    <p className="text-2xl font-bold text-warning">₹{stats.pending.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-info" />
                  <div>
                    <p className="text-sm text-muted-foreground">Students</p>
                    <p className="text-2xl font-bold text-info">{stats.students}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Student Payment Status */}
          <Card>
            <CardHeader>
              <CardTitle>Payment Status - {selectedClass}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {filteredStudents.map(student => (
                  <div key={student.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex items-center gap-4">
                      <img
                        src={student.profileImage}
                        alt={student.name}
                        className="h-10 w-10 rounded-full"
                      />
                      <div>
                        <p className="font-medium">{student.name}</p>
                        <p className="text-sm text-muted-foreground">
                          Roll No: {student.rollNo} | Class: {student.class}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="font-medium">₹{student.paidAmount.toLocaleString()} / ₹{student.totalFees.toLocaleString()}</p>
                        <p className="text-sm text-muted-foreground">
                          Pending: ₹{student.pendingAmount.toLocaleString()}
                        </p>
                      </div>
                      {getStatusBadge(student.status)}
                      <div className="flex gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm" onClick={() => setSelectedStudent(student)}>
                              <Eye className="h-4 w-4 mr-2" />
                              Details
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl">
                            <DialogHeader>
                              <DialogTitle>Payment Details - {student.name}</DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <Label>Total Fees</Label>
                                  <p className="text-lg font-semibold">₹{student.totalFees.toLocaleString()}</p>
                                </div>
                                <div>
                                  <Label>Amount Paid</Label>
                                  <p className="text-lg font-semibold text-success">₹{student.paidAmount.toLocaleString()}</p>
                                </div>
                                <div>
                                  <Label>Pending Amount</Label>
                                  <p className="text-lg font-semibold text-warning">₹{student.pendingAmount.toLocaleString()}</p>
                                </div>
                                <div>
                                  <Label>Last Payment</Label>
                                  <p className="text-lg font-semibold">{student.lastPayment || 'No payment'}</p>
                                </div>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                        {student.pendingAmount > 0 && (
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button size="sm" onClick={() => setSelectedStudent(student)}>
                                <CreditCard className="h-4 w-4 mr-2" />
                                Pay Now
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Make Payment - {student.name}</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div>
                                  <Label>Pending Amount: ₹{student.pendingAmount.toLocaleString()}</Label>
                                </div>
                                <div>
                                  <Label htmlFor="amount">Payment Amount</Label>
                                  <Input
                                    id="amount"
                                    type="number"
                                    placeholder="Enter amount"
                                    value={paymentAmount}
                                    onChange={(e) => setPaymentAmount(e.target.value)}
                                    max={student.pendingAmount}
                                  />
                                </div>
                                <div>
                                  <Label htmlFor="method">Payment Method</Label>
                                  <Select value={selectedMethod} onValueChange={setSelectedMethod}>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select payment method" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {paymentMethods.map(method => (
                                        <SelectItem key={method.id} value={method.id}>
                                          {method.name}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                </div>
                                <div>
                                  <Label htmlFor="remark">Remark (Optional)</Label>
                                  <Textarea
                                    id="remark"
                                    placeholder="Add payment remark"
                                    value={paymentRemark}
                                    onChange={(e) => setPaymentRemark(e.target.value)}
                                  />
                                </div>
                                <Button onClick={handlePayment} className="w-full" disabled={!paymentAmount || !selectedMethod}>
                                  <CreditCard className="h-4 w-4 mr-2" />
                                  Process Payment
                                </Button>
                              </div>
                            </DialogContent>
                          </Dialog>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="structure" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Fee Structure</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {feeCategories.map(category => (
                  <div key={category.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">{category.name}</p>
                      <p className="text-sm text-muted-foreground">Due Date: {category.dueDate}</p>
                    </div>
                    <p className="text-lg font-semibold">₹{category.amount.toLocaleString()}</p>
                  </div>
                ))}
                <div className="border-t pt-4">
                  <div className="flex items-center justify-between">
                    <p className="text-lg font-semibold">Total Annual Fee</p>
                    <p className="text-xl font-bold text-primary">
                      ₹{feeCategories.reduce((sum, cat) => sum + cat.amount, 0).toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Payments</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <Receipt className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Payment History</h3>
                <p className="text-muted-foreground">Payment transaction history would appear here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
