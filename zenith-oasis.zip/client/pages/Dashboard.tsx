import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import {
  Users,
  GraduationCap,
  DollarSign,
  Calendar,
  Bell,
  TrendingUp,
  Clock,
  CheckCircle,
  AlertCircle,
  CalendarCheck,
  CreditCard,
  Bus,
  BookOpen,
  MessageSquare,
  FileText,
  Library,
  User,
} from "lucide-react";

const quickLinks = [
  {
    title: "Mark Attendance",
    description: "Take today's attendance",
    href: "/attendance",
    icon: CalendarCheck,
    color: "bg-accent/10 text-accent hover:bg-accent/20",
  },
  {
    title: "Pay Fees",
    description: "Make fee payments",
    href: "/fees",
    icon: CreditCard,
    color: "bg-warning/10 text-warning hover:bg-warning/20",
  },
  {
    title: "Track Bus",
    description: "View bus location",
    href: "/transport",
    icon: Bus,
    color: "bg-info/10 text-info hover:bg-info/20",
  },
  {
    title: "View Homework",
    description: "Check assignments",
    href: "/homework",
    icon: BookOpen,
    color: "bg-success/10 text-success hover:bg-success/20",
  },
  {
    title: "Notice Board",
    description: "Latest announcements",
    href: "/communication",
    icon: MessageSquare,
    color: "bg-primary/10 text-primary hover:bg-primary/20",
  },
  {
    title: "Results",
    description: "View report cards",
    href: "/results",
    icon: FileText,
    color: "bg-info/10 text-info hover:bg-info/20",
  },
  {
    title: "Library",
    description: "Search & issue books",
    href: "/library",
    icon: Library,
    color: "bg-success/10 text-success hover:bg-success/20",
  },
  {
    title: "Profile",
    description: "Update your info",
    href: "/profile",
    icon: User,
    color: "bg-warning/10 text-warning hover:bg-warning/20",
  },
];

const stats = [
  {
    title: "Total Students",
    value: "1,248",
    change: "+12%",
    changeType: "positive" as const,
    icon: Users,
    color: "text-primary",
  },
  {
    title: "Present Today",
    value: "1,156",
    change: "92.6%",
    changeType: "positive" as const,
    icon: CheckCircle,
    color: "text-success",
  },
  {
    title: "Fees Pending",
    value: "₹2.4L",
    change: "-8%",
    changeType: "positive" as const,
    icon: DollarSign,
    color: "text-warning",
  },
  {
    title: "Active Buses",
    value: "24/28",
    change: "85.7%",
    changeType: "neutral" as const,
    icon: Bus,
    color: "text-info",
  },
];

const recentActivity = [
  {
    id: 1,
    type: "attendance",
    message: "Attendance marked for Class 10A",
    time: "2 minutes ago",
    icon: CalendarCheck,
    color: "text-accent",
  },
  {
    id: 2,
    type: "payment",
    message: "Fee payment received from John Doe",
    time: "15 minutes ago",
    icon: CreditCard,
    color: "text-success",
  },
  {
    id: 3,
    type: "notice",
    message: "New notice posted: Sports Day Schedule",
    time: "1 hour ago",
    icon: MessageSquare,
    color: "text-primary",
  },
  {
    id: 4,
    type: "homework",
    message: "Math homework assigned to Class 9B",
    time: "2 hours ago",
    icon: BookOpen,
    color: "text-info",
  },
];

export default function Dashboard() {
  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-lg p-6">
        <h1 className="text-3xl font-bold text-foreground mb-2">
          Welcome to SchoolHub
        </h1>
        <p className="text-muted-foreground text-lg">
          Your complete school management solution. Everything you need in one place.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">
                      {stat.title}
                    </p>
                    <p className="text-3xl font-bold text-foreground">
                      {stat.value}
                    </p>
                    <p
                      className={`text-sm font-medium mt-1 ${
                        stat.changeType === "positive"
                          ? "text-success"
                          : stat.changeType === "negative"
                          ? "text-destructive"
                          : "text-muted-foreground"
                      }`}
                    >
                      {stat.change}
                    </p>
                  </div>
                  <div className={`p-3 rounded-full bg-muted ${stat.color}`}>
                    <Icon className="h-6 w-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Quick Links */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Quick Actions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {quickLinks.map((link) => {
                  const Icon = link.icon;
                  return (
                    <Link
                      key={link.title}
                      to={link.href}
                      className="group"
                    >
                      <div className={`p-4 rounded-lg border-2 border-transparent hover:border-border transition-all ${link.color}`}>
                        <Icon className="h-8 w-8 mb-3" />
                        <h3 className="font-semibold text-foreground mb-1">
                          {link.title}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          {link.description}
                        </p>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-primary" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {recentActivity.map((activity) => {
                const Icon = activity.icon;
                return (
                  <div key={activity.id} className="flex items-start gap-3">
                    <div className={`p-2 rounded-full bg-muted ${activity.color}`}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-foreground">
                        {activity.message}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {activity.time}
                      </p>
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Important Notices */}
      <Card className="border-l-4 border-l-primary">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-primary" />
            Important Notices
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-start gap-3 p-4 bg-primary/5 rounded-lg">
              <AlertCircle className="h-5 w-5 text-primary mt-0.5" />
              <div>
                <h4 className="font-semibold text-foreground">
                  Annual Sports Day - March 15th
                </h4>
                <p className="text-sm text-muted-foreground">
                  All students are required to participate. Registration closes on March 10th.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-4 bg-warning/5 rounded-lg">
              <AlertCircle className="h-5 w-5 text-warning mt-0.5" />
              <div>
                <h4 className="font-semibold text-foreground">
                  Parent-Teacher Meeting
                </h4>
                <p className="text-sm text-muted-foreground">
                  Scheduled for this Saturday, March 9th from 10 AM to 4 PM.
                </p>
              </div>
            </div>
            <div className="text-center">
              <Button variant="outline" asChild>
                <Link to="/communication">View All Notices</Link>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
