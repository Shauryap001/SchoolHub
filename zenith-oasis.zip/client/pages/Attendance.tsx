import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import {
  ArrowLeft,
  CalendarCheck,
  Users,
  CheckCircle,
  XCircle,
  Search,
  Download,
  Calendar,
  Clock,
  AlertCircle,
} from "lucide-react";

// Mock data
const classes = [
  { id: '1', name: 'Class 10A', students: 35 },
  { id: '2', name: 'Class 10B', students: 32 },
  { id: '3', name: 'Class 9A', students: 38 },
  { id: '4', name: 'Class 9B', students: 33 },
];

const mockStudents = [
  { id: '1', name: 'John Doe', rollNo: '001', status: 'present' as const, profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=John' },
  { id: '2', name: 'Jane Smith', rollNo: '002', status: 'present' as const, profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Jane' },
  { id: '3', name: 'Mike Johnson', rollNo: '003', status: 'absent' as const, profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Mike' },
  { id: '4', name: 'Sarah Wilson', rollNo: '004', status: 'present' as const, profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Sarah' },
  { id: '5', name: 'David Brown', rollNo: '005', status: 'late' as const, profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=David' },
  { id: '6', name: 'Emily Davis', rollNo: '006', status: 'present' as const, profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Emily' },
  { id: '7', name: 'Alex Miller', rollNo: '007', status: 'absent' as const, profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Alex' },
  { id: '8', name: 'Lisa Garcia', rollNo: '008', status: 'present' as const, profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Lisa' },
];

export default function Attendance() {
  const [selectedClass, setSelectedClass] = useState('1');
  const [students, setStudents] = useState(mockStudents);
  const [searchTerm, setSearchTerm] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  const filteredStudents = students.filter(student =>
    student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    student.rollNo.includes(searchTerm)
  );

  const toggleAttendance = (studentId: string) => {
    setStudents(prev => prev.map(student => {
      if (student.id === studentId) {
        const statusOrder = ['present', 'absent', 'late'] as const;
        const currentIndex = statusOrder.indexOf(student.status);
        const nextIndex = (currentIndex + 1) % statusOrder.length;
        return { ...student, status: statusOrder[nextIndex] };
      }
      return student;
    }));
  };

  const markAllPresent = () => {
    setStudents(prev => prev.map(student => ({ ...student, status: 'present' as const })));
  };

  const markAllAbsent = () => {
    setStudents(prev => prev.map(student => ({ ...student, status: 'absent' as const })));
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'present':
        return <CheckCircle className="h-4 w-4 text-success" />;
      case 'absent':
        return <XCircle className="h-4 w-4 text-destructive" />;
      case 'late':
        return <Clock className="h-4 w-4 text-warning" />;
      default:
        return <AlertCircle className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      present: 'bg-success/10 text-success hover:bg-success/20',
      absent: 'bg-destructive/10 text-destructive hover:bg-destructive/20',
      late: 'bg-warning/10 text-warning hover:bg-warning/20',
    };
    
    return (
      <Badge className={variants[status as keyof typeof variants] || 'bg-muted text-muted-foreground'}>
        {getStatusIcon(status)}
        <span className="ml-1 capitalize">{status}</span>
      </Badge>
    );
  };

  const stats = {
    total: filteredStudents.length,
    present: filteredStudents.filter(s => s.status === 'present').length,
    absent: filteredStudents.filter(s => s.status === 'absent').length,
    late: filteredStudents.filter(s => s.status === 'late').length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="sm" asChild>
            <Link to="/">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <CalendarCheck className="h-8 w-8 text-primary" />
              Attendance Management
            </h1>
            <p className="text-muted-foreground">Mark and track student attendance</p>
          </div>
        </div>
        <Button>
          <Download className="h-4 w-4 mr-2" />
          Export Report
        </Button>
      </div>

      {/* Controls */}
      <Card>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Class</label>
              <Select value={selectedClass} onValueChange={setSelectedClass}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {classes.map(cls => (
                    <SelectItem key={cls.id} value={cls.id}>
                      {cls.name} ({cls.students} students)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Date</label>
              <Input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Search Students</label>
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by name or roll number"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex items-end gap-2">
              <Button variant="outline" onClick={markAllPresent} className="flex-1">
                <CheckCircle className="h-4 w-4 mr-2" />
                All Present
              </Button>
              <Button variant="outline" onClick={markAllAbsent} className="flex-1">
                <XCircle className="h-4 w-4 mr-2" />
                All Absent
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="attendance" className="space-y-6">
        <TabsList>
          <TabsTrigger value="attendance">Take Attendance</TabsTrigger>
          <TabsTrigger value="calendar">Calendar View</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="attendance" className="space-y-6">
          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Total</p>
                    <p className="text-2xl font-bold">{stats.total}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-success" />
                  <div>
                    <p className="text-sm text-muted-foreground">Present</p>
                    <p className="text-2xl font-bold text-success">{stats.present}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <XCircle className="h-5 w-5 text-destructive" />
                  <div>
                    <p className="text-sm text-muted-foreground">Absent</p>
                    <p className="text-2xl font-bold text-destructive">{stats.absent}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-warning" />
                  <div>
                    <p className="text-sm text-muted-foreground">Late</p>
                    <p className="text-2xl font-bold text-warning">{stats.late}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Student List */}
          <Card>
            <CardHeader>
              <CardTitle>Student Attendance - {classes.find(c => c.id === selectedClass)?.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {filteredStudents.map(student => (
                  <div key={student.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex items-center gap-4">
                      <img
                        src={student.profileImage}
                        alt={student.name}
                        className="h-10 w-10 rounded-full"
                      />
                      <div>
                        <p className="font-medium">{student.name}</p>
                        <p className="text-sm text-muted-foreground">Roll No: {student.rollNo}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      {getStatusBadge(student.status)}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => toggleAttendance(student.id)}
                      >
                        Toggle Status
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calendar" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Attendance Calendar
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Calendar View</h3>
                <p className="text-muted-foreground mb-4">
                  Interactive calendar showing attendance patterns would appear here
                </p>
                <div className="bg-muted/50 rounded-lg p-8">
                  <p className="text-sm text-muted-foreground">
                    Calendar component with attendance data visualization
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Attendance Reports</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Weekly Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span>Monday</span>
                        <span className="text-success">95%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Tuesday</span>
                        <span className="text-success">92%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Wednesday</span>
                        <span className="text-success">97%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Thursday</span>
                        <span className="text-warning">88%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Friday</span>
                        <span className="text-success">94%</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Class Ranking</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span>Class 10A</span>
                        <span className="text-success">96%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Class 9A</span>
                        <span className="text-success">94%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Class 10B</span>
                        <span className="text-success">91%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Class 9B</span>
                        <span className="text-warning">87%</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
