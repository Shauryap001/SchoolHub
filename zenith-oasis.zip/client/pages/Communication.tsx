import { PlaceholderPage } from "../components/PlaceholderPage";
import { MessageSquare } from "lucide-react";

export default function Communication() {
  return (
    <PlaceholderPage
      title="Communication & Notice Board"
      description="Share announcements and manage school communication"
      icon={MessageSquare}
      features={[
        "School-wide announcements",
        "Class-specific notices",
        "Event notifications",
        "Emergency alerts",
        "Parent-teacher messaging",
        "SMS and email integration",
        "Notice board archive"
      ]}
    />
  );
}
