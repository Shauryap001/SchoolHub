import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../components/ui/dialog";
import { Switch } from "../components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import {
  ArrowLeft,
  Users,
  UserPlus,
  Search,
  Filter,
  Edit,
  Trash2,
  Settings,
  Shield,
  Bell,
  Palette,
  Mail,
  Database,
  Crown,
  GraduationCap,
  UserCheck,
  Heart,
} from "lucide-react";
import { toast } from "sonner";

// Mock user data
const mockUsers = [
  {
    id: '1',
    name: 'John Administrator',
    email: 'admin@school.com',
    role: 'admin' as const,
    status: 'active' as const,
    lastLogin: '2024-01-20 09:00',
    department: 'Administration',
    phone: '+1-555-0101',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Admin',
  },
  {
    id: '2',
    name: 'Sarah Teacher',
    email: 'teacher@school.com',
    role: 'teacher' as const,
    status: 'active' as const,
    lastLogin: '2024-01-20 08:30',
    department: 'Mathematics',
    phone: '+1-555-0102',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Teacher',
  },
  {
    id: '3',
    name: 'Alex Student',
    email: 'student@school.com',
    role: 'student' as const,
    status: 'active' as const,
    lastLogin: '2024-01-20 07:45',
    department: 'Class 10A',
    phone: '+1-555-0103',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Student',
  },
  {
    id: '4',
    name: 'Michael Parent',
    email: 'parent@school.com',
    role: 'parent' as const,
    status: 'active' as const,
    lastLogin: '2024-01-19 19:30',
    department: 'Parent Portal',
    phone: '+1-555-0104',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Parent',
  },
  {
    id: '5',
    name: 'Emma Wilson',
    email: 'e.wilson@school.com',
    role: 'teacher' as const,
    status: 'inactive' as const,
    lastLogin: '2024-01-15 16:20',
    department: 'English',
    phone: '+1-555-0105',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Emma',
  },
];

const roles = ['admin', 'teacher', 'student', 'parent'];
const departments = ['Administration', 'Mathematics', 'English', 'Science', 'History', 'Geography', 'Physical Education'];

export default function UserManagement() {
  const [users, setUsers] = useState(mockUsers);
  const [filteredUsers, setFilteredUsers] = useState(mockUsers);
  const [selectedRole, setSelectedRole] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddDialog, setShowAddDialog] = useState(false);

  // System settings
  const [systemSettings, setSystemSettings] = useState({
    emailNotifications: true,
    smsNotifications: false,
    pushNotifications: true,
    autoBackup: true,
    maintenanceMode: false,
    registrationOpen: true,
    publicAccess: false,
  });

  // Theme settings
  const [themeSettings, setThemeSettings] = useState({
    primaryColor: '#2563eb',
    secondaryColor: '#10b981',
    theme: 'light',
    logo: 'default',
  });

  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    role: '',
    department: '',
    phone: '',
    password: '',
  });

  // Apply filters
  const applyFilters = () => {
    let filtered = users;

    if (selectedRole !== 'all') {
      filtered = filtered.filter(user => user.role === selectedRole);
    }

    if (selectedStatus !== 'all') {
      filtered = filtered.filter(user => user.status === selectedStatus);
    }

    if (searchTerm) {
      filtered = filtered.filter(user =>
        user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.department.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredUsers(filtered);
  };

  // Apply filters when dependencies change
  useState(() => {
    applyFilters();
  });

  const handleAddUser = () => {
    if (!newUser.name || !newUser.email || !newUser.role) {
      toast.error("Please fill in required fields");
      return;
    }

    const user = {
      id: Date.now().toString(),
      ...newUser,
      status: 'active' as const,
      lastLogin: 'Never',
      profileImage: `https://api.dicebear.com/7.x/initials/svg?seed=${newUser.name}`,
    };

    setUsers(prev => [...prev, user]);
    setNewUser({
      name: '',
      email: '',
      role: '',
      department: '',
      phone: '',
      password: '',
    });
    setShowAddDialog(false);
    toast.success("User added successfully!");
  };

  const toggleUserStatus = (userId: string) => {
    setUsers(prev => prev.map(user => 
      user.id === userId 
        ? { ...user, status: user.status === 'active' ? 'inactive' as const : 'active' as const }
        : user
    ));
    toast.success("User status updated!");
  };

  const deleteUser = (userId: string) => {
    setUsers(prev => prev.filter(user => user.id !== userId));
    toast.success("User deleted successfully!");
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'admin': return <Crown className="h-4 w-4" />;
      case 'teacher': return <GraduationCap className="h-4 w-4" />;
      case 'student': return <UserCheck className="h-4 w-4" />;
      case 'parent': return <Heart className="h-4 w-4" />;
      default: return <Users className="h-4 w-4" />;
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-destructive/10 text-destructive';
      case 'teacher': return 'bg-primary/10 text-primary';
      case 'student': return 'bg-success/10 text-success';
      case 'parent': return 'bg-warning/10 text-warning';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusBadge = (status: string) => {
    return (
      <Badge className={status === 'active' ? 'bg-success/10 text-success' : 'bg-muted text-muted-foreground'}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const stats = {
    total: users.length,
    active: users.filter(user => user.status === 'active').length,
    inactive: users.filter(user => user.status === 'inactive').length,
    admins: users.filter(user => user.role === 'admin').length,
    teachers: users.filter(user => user.role === 'teacher').length,
    students: users.filter(user => user.role === 'student').length,
    parents: users.filter(user => user.role === 'parent').length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="sm" asChild>
            <Link to="/">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Settings className="h-8 w-8 text-primary" />
              User Management & System Settings
            </h1>
            <p className="text-muted-foreground">Manage users, roles, and system configuration</p>
          </div>
        </div>
      </div>

      <Tabs defaultValue="users" className="space-y-6">
        <TabsList>
          <TabsTrigger value="users">User Management</TabsTrigger>
          <TabsTrigger value="roles">Roles & Permissions</TabsTrigger>
          <TabsTrigger value="system">System Settings</TabsTrigger>
          <TabsTrigger value="theme">Theme & Appearance</TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="space-y-6">
          {/* Statistics */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Total Users</p>
                    <p className="text-2xl font-bold">{stats.total}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <UserCheck className="h-5 w-5 text-success" />
                  <div>
                    <p className="text-sm text-muted-foreground">Active Users</p>
                    <p className="text-2xl font-bold text-success">{stats.active}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <GraduationCap className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Teachers</p>
                    <p className="text-2xl font-bold text-primary">{stats.teachers}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Crown className="h-5 w-5 text-destructive" />
                  <div>
                    <p className="text-sm text-muted-foreground">Admins</p>
                    <p className="text-2xl font-bold text-destructive">{stats.admins}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Controls */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 flex-1">
                  <div>
                    <Label>Filter by Role</Label>
                    <Select value={selectedRole} onValueChange={(value) => {setSelectedRole(value); setTimeout(applyFilters, 0);}}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Roles</SelectItem>
                        {roles.map(role => (
                          <SelectItem key={role} value={role}>
                            <div className="flex items-center gap-2">
                              {getRoleIcon(role)}
                              {role.charAt(0).toUpperCase() + role.slice(1)}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Filter by Status</Label>
                    <Select value={selectedStatus} onValueChange={(value) => {setSelectedStatus(value); setTimeout(applyFilters, 0);}}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="inactive">Inactive</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="md:col-span-2">
                    <Label>Search Users</Label>
                    <div className="relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search by name, email, or department"
                        value={searchTerm}
                        onChange={(e) => {setSearchTerm(e.target.value); setTimeout(applyFilters, 0);}}
                        className="pl-10"
                      />
                    </div>
                  </div>
                </div>
                <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
                  <DialogTrigger asChild>
                    <Button className="ml-4">
                      <UserPlus className="h-4 w-4 mr-2" />
                      Add User
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New User</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Full Name *</Label>
                          <Input
                            value={newUser.name}
                            onChange={(e) => setNewUser(prev => ({...prev, name: e.target.value}))}
                            placeholder="Enter full name"
                          />
                        </div>
                        <div>
                          <Label>Email *</Label>
                          <Input
                            type="email"
                            value={newUser.email}
                            onChange={(e) => setNewUser(prev => ({...prev, email: e.target.value}))}
                            placeholder="Enter email address"
                          />
                        </div>
                        <div>
                          <Label>Role *</Label>
                          <Select value={newUser.role} onValueChange={(value) => setNewUser(prev => ({...prev, role: value}))}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select role" />
                            </SelectTrigger>
                            <SelectContent>
                              {roles.map(role => (
                                <SelectItem key={role} value={role}>
                                  <div className="flex items-center gap-2">
                                    {getRoleIcon(role)}
                                    {role.charAt(0).toUpperCase() + role.slice(1)}
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Department</Label>
                          <Select value={newUser.department} onValueChange={(value) => setNewUser(prev => ({...prev, department: value}))}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select department" />
                            </SelectTrigger>
                            <SelectContent>
                              {departments.map(dept => (
                                <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Phone</Label>
                          <Input
                            value={newUser.phone}
                            onChange={(e) => setNewUser(prev => ({...prev, phone: e.target.value}))}
                            placeholder="+1-555-0000"
                          />
                        </div>
                        <div>
                          <Label>Password *</Label>
                          <Input
                            type="password"
                            value={newUser.password}
                            onChange={(e) => setNewUser(prev => ({...prev, password: e.target.value}))}
                            placeholder="Enter password"
                          />
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button onClick={handleAddUser}>Add User</Button>
                        <Button variant="outline" onClick={() => setShowAddDialog(false)}>Cancel</Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardContent>
          </Card>

          {/* Users Table */}
          <Card>
            <CardHeader>
              <CardTitle>User Directory</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableCaption>
                  {filteredUsers.length} user{filteredUsers.length !== 1 ? 's' : ''} found
                </TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Login</TableHead>
                    <TableHead>Phone</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={user.profileImage} alt={user.name} />
                            <AvatarFallback>
                              {user.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{user.name}</p>
                            <p className="text-sm text-muted-foreground">{user.email}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getRoleBadgeColor(user.role)}>
                          {getRoleIcon(user.role)}
                          <span className="ml-1 capitalize">{user.role}</span>
                        </Badge>
                      </TableCell>
                      <TableCell>{user.department}</TableCell>
                      <TableCell>{getStatusBadge(user.status)}</TableCell>
                      <TableCell className="text-sm">{user.lastLogin}</TableCell>
                      <TableCell>{user.phone}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center gap-2 justify-end">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => toggleUserStatus(user.id)}
                          >
                            <Shield className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => deleteUser(user.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="roles" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Roles & Permissions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {roles.map(role => (
                  <Card key={role}>
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 mb-4">
                        {getRoleIcon(role)}
                        <h3 className="font-semibold text-lg capitalize">{role}</h3>
                        <Badge variant="outline">
                          {stats[role as keyof typeof stats] || 0} users
                        </Badge>
                      </div>
                      <div className="space-y-2 text-sm text-muted-foreground">
                        {role === 'admin' && (
                          <ul className="space-y-1">
                            <li>• Full system access</li>
                            <li>• User management</li>
                            <li>• System configuration</li>
                            <li>• Reports and analytics</li>
                          </ul>
                        )}
                        {role === 'teacher' && (
                          <ul className="space-y-1">
                            <li>• Class management</li>
                            <li>• Grade entry</li>
                            <li>• Attendance marking</li>
                            <li>• Assignment creation</li>
                          </ul>
                        )}
                        {role === 'student' && (
                          <ul className="space-y-1">
                            <li>• View assignments</li>
                            <li>• Submit homework</li>
                            <li>• Check grades</li>
                            <li>• Access resources</li>
                          </ul>
                        )}
                        {role === 'parent' && (
                          <ul className="space-y-1">
                            <li>• View child's progress</li>
                            <li>• Communication with teachers</li>
                            <li>• Payment management</li>
                            <li>• Event notifications</li>
                          </ul>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="system" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                System Configuration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="font-semibold">Notification Settings</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Email Notifications</p>
                        <p className="text-sm text-muted-foreground">Send system notifications via email</p>
                      </div>
                      <Switch 
                        checked={systemSettings.emailNotifications}
                        onCheckedChange={(checked) => setSystemSettings(prev => ({...prev, emailNotifications: checked}))}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">SMS Notifications</p>
                        <p className="text-sm text-muted-foreground">Send urgent alerts via SMS</p>
                      </div>
                      <Switch 
                        checked={systemSettings.smsNotifications}
                        onCheckedChange={(checked) => setSystemSettings(prev => ({...prev, smsNotifications: checked}))}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Push Notifications</p>
                        <p className="text-sm text-muted-foreground">Browser push notifications</p>
                      </div>
                      <Switch 
                        checked={systemSettings.pushNotifications}
                        onCheckedChange={(checked) => setSystemSettings(prev => ({...prev, pushNotifications: checked}))}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold">System Access</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Registration Open</p>
                        <p className="text-sm text-muted-foreground">Allow new user registrations</p>
                      </div>
                      <Switch 
                        checked={systemSettings.registrationOpen}
                        onCheckedChange={(checked) => setSystemSettings(prev => ({...prev, registrationOpen: checked}))}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Public Access</p>
                        <p className="text-sm text-muted-foreground">Allow public viewing of basic info</p>
                      </div>
                      <Switch 
                        checked={systemSettings.publicAccess}
                        onCheckedChange={(checked) => setSystemSettings(prev => ({...prev, publicAccess: checked}))}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Maintenance Mode</p>
                        <p className="text-sm text-muted-foreground">Enable maintenance mode</p>
                      </div>
                      <Switch 
                        checked={systemSettings.maintenanceMode}
                        onCheckedChange={(checked) => setSystemSettings(prev => ({...prev, maintenanceMode: checked}))}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold">Backup & Security</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Auto Backup</p>
                        <p className="text-sm text-muted-foreground">Automatic daily backups</p>
                      </div>
                      <Switch 
                        checked={systemSettings.autoBackup}
                        onCheckedChange={(checked) => setSystemSettings(prev => ({...prev, autoBackup: checked}))}
                      />
                    </div>
                    <Button variant="outline" className="w-full">
                      <Database className="h-4 w-4 mr-2" />
                      Create Manual Backup
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Shield className="h-4 w-4 mr-2" />
                      Security Audit
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold">Communication</h3>
                  <div className="space-y-3">
                    <Button variant="outline" className="w-full">
                      <Mail className="h-4 w-4 mr-2" />
                      Email Configuration
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Bell className="h-4 w-4 mr-2" />
                      Notification Templates
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="theme" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="h-5 w-5" />
                Theme & Appearance
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="font-semibold">Color Scheme</h3>
                  <div className="space-y-3">
                    <div>
                      <Label>Primary Color</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          type="color"
                          value={themeSettings.primaryColor}
                          onChange={(e) => setThemeSettings(prev => ({...prev, primaryColor: e.target.value}))}
                          className="w-16 h-10"
                        />
                        <Input
                          value={themeSettings.primaryColor}
                          onChange={(e) => setThemeSettings(prev => ({...prev, primaryColor: e.target.value}))}
                          placeholder="#2563eb"
                        />
                      </div>
                    </div>
                    <div>
                      <Label>Secondary Color</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          type="color"
                          value={themeSettings.secondaryColor}
                          onChange={(e) => setThemeSettings(prev => ({...prev, secondaryColor: e.target.value}))}
                          className="w-16 h-10"
                        />
                        <Input
                          value={themeSettings.secondaryColor}
                          onChange={(e) => setThemeSettings(prev => ({...prev, secondaryColor: e.target.value}))}
                          placeholder="#10b981"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold">Theme Mode</h3>
                  <Select value={themeSettings.theme} onValueChange={(value) => setThemeSettings(prev => ({...prev, theme: value}))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">Light Theme</SelectItem>
                      <SelectItem value="dark">Dark Theme</SelectItem>
                      <SelectItem value="auto">Auto (System)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold">Branding</h3>
                  <div className="space-y-3">
                    <div>
                      <Label>School Logo</Label>
                      <Button variant="outline" className="w-full">
                        Upload New Logo
                      </Button>
                    </div>
                    <div>
                      <Label>School Name</Label>
                      <Input placeholder="SchoolHub" />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold">Preview</h3>
                  <div className="p-4 border rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground">
                      Theme preview would appear here
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <Button>Save Changes</Button>
                <Button variant="outline">Reset to Default</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
