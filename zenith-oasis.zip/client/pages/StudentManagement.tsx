import { useState, useRef } from "react";
import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import {
  ArrowLeft,
  Users,
  UserPlus,
  Upload,
  Download,
  Search,
  Filter,
  Edit,
  Trash2,
  Eye,
  FileSpreadsheet,
  Plus,
  MoreHorizontal,
} from "lucide-react";
import { toast } from "sonner";

// Mock student data
const mockStudents = [
  {
    id: '1',
    name: 'Alex Johnson',
    admissionNumber: 'ADM001',
    class: '10',
    division: 'A',
    phone: '+1-555-1001',
    parentName: 'Robert Johnson',
    parentPhone: '+1-555-1002',
    email: 'alex.johnson@school.com',
    address: '123 Oak Street, Education City',
    dateOfBirth: '2008-05-15',
    gender: 'Male',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Alex',
  },
  {
    id: '2',
    name: 'Emma Wilson',
    admissionNumber: 'ADM002',
    class: '10',
    division: 'A',
    phone: '+1-555-1003',
    parentName: 'Sarah Wilson',
    parentPhone: '+1-555-1004',
    email: 'emma.wilson@school.com',
    address: '456 Pine Avenue, Education City',
    dateOfBirth: '2008-03-22',
    gender: 'Female',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Emma',
  },
  {
    id: '3',
    name: 'Liam Brown',
    admissionNumber: 'ADM003',
    class: '9',
    division: 'B',
    phone: '+1-555-1005',
    parentName: 'Michael Brown',
    parentPhone: '+1-555-1006',
    email: 'liam.brown@school.com',
    address: '789 Maple Road, Education City',
    dateOfBirth: '2009-07-10',
    gender: 'Male',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Liam',
  },
  {
    id: '4',
    name: 'Olivia Davis',
    admissionNumber: 'ADM004',
    class: '8',
    division: 'A',
    phone: '+1-555-1007',
    parentName: 'Jennifer Davis',
    parentPhone: '+1-555-1008',
    email: 'olivia.davis@school.com',
    address: '321 Cedar Lane, Education City',
    dateOfBirth: '2010-11-28',
    gender: 'Female',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Olivia',
  },
  {
    id: '5',
    name: 'Noah Garcia',
    admissionNumber: 'ADM005',
    class: '7',
    division: 'B',
    phone: '+1-555-1009',
    parentName: 'Carlos Garcia',
    parentPhone: '+1-555-1010',
    email: 'noah.garcia@school.com',
    address: '654 Birch Street, Education City',
    dateOfBirth: '2011-01-14',
    gender: 'Male',
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Noah',
  },
];

const classes = Array.from({ length: 10 }, (_, i) => ({
  value: String(i + 1),
  label: `Class ${i + 1}`,
}));

const divisions = ['A', 'B', 'C', 'D'];

export default function StudentManagement() {
  const [students, setStudents] = useState(mockStudents);
  const [filteredStudents, setFilteredStudents] = useState(mockStudents);
  const [selectedClass, setSelectedClass] = useState('all');
  const [selectedDivision, setSelectedDivision] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [newStudent, setNewStudent] = useState({
    name: '',
    admissionNumber: '',
    class: '',
    division: '',
    phone: '',
    parentName: '',
    parentPhone: '',
    email: '',
    address: '',
    dateOfBirth: '',
    gender: '',
  });

  // Filter students based on search and filters
  const applyFilters = () => {
    let filtered = students;

    if (selectedClass !== 'all') {
      filtered = filtered.filter(student => student.class === selectedClass);
    }

    if (selectedDivision !== 'all') {
      filtered = filtered.filter(student => student.division === selectedDivision);
    }

    if (searchTerm) {
      filtered = filtered.filter(student =>
        student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.admissionNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.parentName.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredStudents(filtered);
  };

  // Apply filters whenever dependencies change
  useState(() => {
    applyFilters();
  });

  const handleAddStudent = () => {
    if (!newStudent.name || !newStudent.admissionNumber || !newStudent.class) {
      toast.error("Please fill in required fields");
      return;
    }

    const student = {
      id: Date.now().toString(),
      ...newStudent,
      profileImage: `https://api.dicebear.com/7.x/initials/svg?seed=${newStudent.name}`,
    };

    setStudents(prev => [...prev, student]);
    setNewStudent({
      name: '',
      admissionNumber: '',
      class: '',
      division: '',
      phone: '',
      parentName: '',
      parentPhone: '',
      email: '',
      address: '',
      dateOfBirth: '',
      gender: '',
    });
    setShowAddDialog(false);
    toast.success("Student added successfully!");
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.csv') && !file.name.endsWith('.xlsx')) {
      toast.error("Please upload a CSV or Excel file");
      return;
    }

    // Mock file processing
    setTimeout(() => {
      const mockImportedStudents = [
        {
          id: Date.now().toString(),
          name: 'John Smith',
          admissionNumber: 'ADM100',
          class: '5',
          division: 'A',
          phone: '+1-555-2001',
          parentName: 'Mary Smith',
          parentPhone: '+1-555-2002',
          email: 'john.smith@school.com',
          address: '100 Import Street, Education City',
          dateOfBirth: '2013-04-15',
          gender: 'Male',
          profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=John',
        },
        {
          id: (Date.now() + 1).toString(),
          name: 'Jane Doe',
          admissionNumber: 'ADM101',
          class: '5',
          division: 'A',
          phone: '+1-555-2003',
          parentName: 'Bob Doe',
          parentPhone: '+1-555-2004',
          email: 'jane.doe@school.com',
          address: '101 Import Street, Education City',
          dateOfBirth: '2013-06-20',
          gender: 'Female',
          profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Jane',
        },
      ];

      setStudents(prev => [...prev, ...mockImportedStudents]);
      setShowImportDialog(false);
      toast.success(`Imported ${mockImportedStudents.length} students successfully!`);
    }, 1500);

    toast.info("Processing file...");
  };

  const exportData = () => {
    const csvContent = [
      ['Name', 'Admission Number', 'Class', 'Division', 'Phone', 'Parent Name', 'Parent Phone', 'Email'].join(','),
      ...filteredStudents.map(student => 
        [student.name, student.admissionNumber, student.class, student.division, student.phone, student.parentName, student.parentPhone, student.email].join(',')
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'students_data.csv';
    a.click();
    window.URL.revokeObjectURL(url);
    toast.success("Data exported successfully!");
  };

  const deleteStudent = (id: string) => {
    setStudents(prev => prev.filter(student => student.id !== id));
    toast.success("Student deleted successfully!");
  };

  const stats = {
    total: filteredStudents.length,
    totalAll: students.length,
    byClass: classes.map(cls => ({
      class: cls.value,
      count: students.filter(s => s.class === cls.value).length
    })).filter(item => item.count > 0),
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="sm" asChild>
            <Link to="/">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Users className="h-8 w-8 text-primary" />
              Student Management
            </h1>
            <p className="text-muted-foreground">Manage student records and information</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={exportData}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Upload className="h-4 w-4 mr-2" />
                Import
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Import Student Data</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Upload CSV or Excel File</Label>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".csv,.xlsx,.xls"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <Button 
                    onClick={() => fileInputRef.current?.click()}
                    variant="outline" 
                    className="w-full mt-2"
                  >
                    <FileSpreadsheet className="h-4 w-4 mr-2" />
                    Choose File
                  </Button>
                </div>
                <div className="text-sm text-muted-foreground">
                  <p>File should contain columns:</p>
                  <ul className="list-disc list-inside mt-1 space-y-1">
                    <li>Name</li>
                    <li>Admission Number</li>
                    <li>Class (1-10)</li>
                    <li>Division (A, B, C, D)</li>
                    <li>Phone Number</li>
                    <li>Parent Name</li>
                    <li>Parent Phone</li>
                    <li>Email (optional)</li>
                  </ul>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button>
                <UserPlus className="h-4 w-4 mr-2" />
                Add Student
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Add New Student</DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Name *</Label>
                  <Input
                    id="name"
                    value={newStudent.name}
                    onChange={(e) => setNewStudent(prev => ({...prev, name: e.target.value}))}
                    placeholder="Student name"
                  />
                </div>
                <div>
                  <Label htmlFor="admission">Admission Number *</Label>
                  <Input
                    id="admission"
                    value={newStudent.admissionNumber}
                    onChange={(e) => setNewStudent(prev => ({...prev, admissionNumber: e.target.value}))}
                    placeholder="ADM001"
                  />
                </div>
                <div>
                  <Label htmlFor="class">Class *</Label>
                  <Select value={newStudent.class} onValueChange={(value) => setNewStudent(prev => ({...prev, class: value}))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select class" />
                    </SelectTrigger>
                    <SelectContent>
                      {classes.map(cls => (
                        <SelectItem key={cls.value} value={cls.value}>{cls.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="division">Division</Label>
                  <Select value={newStudent.division} onValueChange={(value) => setNewStudent(prev => ({...prev, division: value}))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select division" />
                    </SelectTrigger>
                    <SelectContent>
                      {divisions.map(div => (
                        <SelectItem key={div} value={div}>Division {div}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="phone">Student Phone</Label>
                  <Input
                    id="phone"
                    value={newStudent.phone}
                    onChange={(e) => setNewStudent(prev => ({...prev, phone: e.target.value}))}
                    placeholder="+1-555-0000"
                  />
                </div>
                <div>
                  <Label htmlFor="parentName">Parent Name</Label>
                  <Input
                    id="parentName"
                    value={newStudent.parentName}
                    onChange={(e) => setNewStudent(prev => ({...prev, parentName: e.target.value}))}
                    placeholder="Parent/Guardian name"
                  />
                </div>
                <div>
                  <Label htmlFor="parentPhone">Parent Phone</Label>
                  <Input
                    id="parentPhone"
                    value={newStudent.parentPhone}
                    onChange={(e) => setNewStudent(prev => ({...prev, parentPhone: e.target.value}))}
                    placeholder="+1-555-0000"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={newStudent.email}
                    onChange={(e) => setNewStudent(prev => ({...prev, email: e.target.value}))}
                    placeholder="student@school.com"
                  />
                </div>
              </div>
              <div className="flex gap-2 mt-6">
                <Button onClick={handleAddStudent}>Add Student</Button>
                <Button variant="outline" onClick={() => setShowAddDialog(false)}>Cancel</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Total Students</p>
                <p className="text-2xl font-bold">{stats.totalAll}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Filter className="h-5 w-5 text-success" />
              <div>
                <p className="text-sm text-muted-foreground">Filtered Results</p>
                <p className="text-2xl font-bold text-success">{stats.total}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <UserPlus className="h-5 w-5 text-info" />
              <div>
                <p className="text-sm text-muted-foreground">Classes Active</p>
                <p className="text-2xl font-bold text-info">{stats.byClass.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Search className="h-5 w-5 text-warning" />
              <div>
                <p className="text-sm text-muted-foreground">Search Active</p>
                <p className="text-2xl font-bold text-warning">{searchTerm ? 'Yes' : 'No'}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label>Filter by Class</Label>
              <Select value={selectedClass} onValueChange={(value) => {setSelectedClass(value); setTimeout(applyFilters, 0);}}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Classes</SelectItem>
                  {classes.map(cls => (
                    <SelectItem key={cls.value} value={cls.value}>{cls.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Filter by Division</Label>
              <Select value={selectedDivision} onValueChange={(value) => {setSelectedDivision(value); setTimeout(applyFilters, 0);}}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Divisions</SelectItem>
                  {divisions.map(div => (
                    <SelectItem key={div} value={div}>Division {div}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="md:col-span-2">
              <Label>Search Students</Label>
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by name, admission number, or parent name"
                  value={searchTerm}
                  onChange={(e) => {setSearchTerm(e.target.value); setTimeout(applyFilters, 0);}}
                  className="pl-10"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Students Table */}
      <Card>
        <CardHeader>
          <CardTitle>Student Records</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableCaption>
              {filteredStudents.length} student{filteredStudents.length !== 1 ? 's' : ''} found
            </TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>Student</TableHead>
                <TableHead>Admission No.</TableHead>
                <TableHead>Class</TableHead>
                <TableHead>Division</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead>Parent Name</TableHead>
                <TableHead>Parent Phone</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredStudents.map((student) => (
                <TableRow key={student.id}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={student.profileImage} alt={student.name} />
                        <AvatarFallback>
                          {student.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{student.name}</p>
                        <p className="text-sm text-muted-foreground">{student.email}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{student.admissionNumber}</Badge>
                  </TableCell>
                  <TableCell>{student.class}</TableCell>
                  <TableCell>
                    <Badge>{student.division}</Badge>
                  </TableCell>
                  <TableCell>{student.phone}</TableCell>
                  <TableCell>{student.parentName}</TableCell>
                  <TableCell>{student.parentPhone}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center gap-2 justify-end">
                      <Button variant="ghost" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => deleteStudent(student.id)}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
