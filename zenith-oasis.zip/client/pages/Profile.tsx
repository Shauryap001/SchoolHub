import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import { Badge } from "../components/ui/badge";
import { Switch } from "../components/ui/switch";
import { Textarea } from "../components/ui/textarea";
import { useAuth, User as UserType } from "../contexts/AuthContext";
import {
  ArrowLeft,
  User,
  Camera,
  Settings,
  Bell,
  Shield,
  HelpCircle,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Users,
  GraduationCap,
  UserCheck,
  Crown,
} from "lucide-react";
import { toast } from "sonner";

// Mock account data for switching
const mockAccounts = [
  {
    id: '1',
    email: 'admin@school.com',
    name: 'John Administrator',
    role: 'admin' as const,
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Admin',
    phone: '+1-555-0101',
    address: '123 School Admin St, Education City',
    department: 'Administration',
    joinDate: '2020-01-15',
  },
  {
    id: '2',
    email: 'teacher@school.com',
    name: 'Sarah Teacher',
    role: 'teacher' as const,
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Teacher',
    phone: '+1-555-0102',
    address: '456 Teacher Ave, Education City',
    department: 'Mathematics',
    joinDate: '2021-08-20',
  },
  {
    id: '3',
    email: 'student@school.com',
    name: 'Alex Student',
    role: 'student' as const,
    profileImage: 'https://api.dicebear.com/7.x/initials/svg?seed=Student',
    phone: '+1-555-0103',
    address: '789 Student Blvd, Education City',
    department: 'Class 10A',
    joinDate: '2023-09-01',
  },
];

export default function Profile() {
  const { user, logout } = useAuth();
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: mockAccounts.find(acc => acc.role === user?.role)?.phone || '',
    address: mockAccounts.find(acc => acc.role === user?.role)?.address || '',
  });
  const [notifications, setNotifications] = useState({
    email: true,
    sms: false,
    push: true,
    updates: true,
  });

  const currentAccount = mockAccounts.find(acc => acc.role === user?.role) || mockAccounts[2];

  const switchAccount = async (newRole: UserType['role']) => {
    const account = mockAccounts.find(acc => acc.role === newRole);
    if (account) {
      // Simulate account switching
      logout();
      
      // Mock login with new account
      setTimeout(() => {
        const newUser: UserType = {
          id: account.id,
          email: account.email,
          name: account.name,
          role: account.role,
          profileImage: account.profileImage,
        };
        
        localStorage.setItem('schoolhub_user', JSON.stringify(newUser));
        window.location.reload(); // Refresh to apply new user context
      }, 500);
      
      toast.success(`Switched to ${newRole} account`);
    }
  };

  const updateFormData = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    // Mock save functionality
    toast.success("Profile updated successfully!");
    setEditMode(false);
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'admin':
        return <Crown className="h-4 w-4" />;
      case 'teacher':
        return <GraduationCap className="h-4 w-4" />;
      case 'student':
        return <UserCheck className="h-4 w-4" />;
      default:
        return <User className="h-4 w-4" />;
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'admin':
        return 'bg-destructive/10 text-destructive';
      case 'teacher':
        return 'bg-primary/10 text-primary';
      case 'student':
        return 'bg-success/10 text-success';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="sm" asChild>
            <Link to="/">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <User className="h-8 w-8 text-primary" />
              Profile & Settings
            </h1>
            <p className="text-muted-foreground">Manage your account and preferences</p>
          </div>
        </div>
      </div>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList>
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="accounts">Account Switching</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6">
          {/* Profile Header */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start gap-6">
                <div className="relative">
                  <Avatar className="h-24 w-24">
                    <AvatarImage src={currentAccount.profileImage} alt={currentAccount.name} />
                    <AvatarFallback className="text-lg">
                      {currentAccount.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <Button size="sm" className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full p-0">
                    <Camera className="h-4 w-4" />
                  </Button>
                </div>
                
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h2 className="text-2xl font-bold">{currentAccount.name}</h2>
                    <Badge className={getRoleBadgeColor(currentAccount.role)}>
                      {getRoleIcon(currentAccount.role)}
                      <span className="ml-1 capitalize">{currentAccount.role}</span>
                    </Badge>
                  </div>
                  <p className="text-muted-foreground mb-4">{currentAccount.email}</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span>{currentAccount.phone}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>Joined {currentAccount.joinDate}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>{currentAccount.address}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <span>{currentAccount.department}</span>
                    </div>
                  </div>
                </div>

                <Button onClick={() => setEditMode(!editMode)}>
                  {editMode ? 'Cancel' : 'Edit Profile'}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Profile Form */}
          {editMode && (
            <Card>
              <CardHeader>
                <CardTitle>Edit Profile Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => updateFormData('name', e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => updateFormData('email', e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => updateFormData('phone', e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="address">Address</Label>
                    <Input
                      id="address"
                      value={formData.address}
                      onChange={(e) => updateFormData('address', e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button onClick={handleSave}>Save Changes</Button>
                  <Button variant="outline" onClick={() => setEditMode(false)}>Cancel</Button>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="accounts" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Account Switching
              </CardTitle>
              <p className="text-muted-foreground">
                Switch between different user roles to experience the system from different perspectives
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              {mockAccounts.map(account => (
                <div 
                  key={account.id} 
                  className={`p-4 border rounded-lg transition-colors ${
                    account.role === user?.role 
                      ? 'border-primary bg-primary/5' 
                      : 'hover:bg-muted/50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={account.profileImage} alt={account.name} />
                        <AvatarFallback>
                          {account.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold">{account.name}</h3>
                          <Badge className={getRoleBadgeColor(account.role)}>
                            {getRoleIcon(account.role)}
                            <span className="ml-1 capitalize">{account.role}</span>
                          </Badge>
                          {account.role === user?.role && (
                            <Badge variant="outline" className="text-xs">Current</Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">{account.email}</p>
                        <p className="text-sm text-muted-foreground">{account.department}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {account.role !== user?.role && (
                        <Button 
                          variant="outline"
                          onClick={() => switchAccount(account.role)}
                        >
                          Switch Account
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
              
              <div className="mt-6 p-4 bg-info/5 border border-info/20 rounded-lg">
                <div className="flex items-start gap-3">
                  <HelpCircle className="h-5 w-5 text-info mt-0.5" />
                  <div>
                    <h4 className="font-medium text-info">Demo Account Switching</h4>
                    <p className="text-sm text-info/80 mt-1">
                      This feature allows you to experience the school management system from different user perspectives. 
                      Each role has different permissions and access levels:
                    </p>
                    <ul className="text-sm text-info/80 mt-2 space-y-1">
                      <li>• <strong>Admin:</strong> Full system access and management capabilities</li>
                      <li>• <strong>Teacher:</strong> Classroom management, grading, and student tracking</li>
                      <li>• <strong>Student:</strong> View assignments, grades, and school information</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Notification Preferences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Email Notifications</p>
                  <p className="text-sm text-muted-foreground">Receive notifications via email</p>
                </div>
                <Switch 
                  checked={notifications.email}
                  onCheckedChange={(checked) => setNotifications(prev => ({...prev, email: checked}))}
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">SMS Notifications</p>
                  <p className="text-sm text-muted-foreground">Receive notifications via SMS</p>
                </div>
                <Switch 
                  checked={notifications.sms}
                  onCheckedChange={(checked) => setNotifications(prev => ({...prev, sms: checked}))}
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Push Notifications</p>
                  <p className="text-sm text-muted-foreground">Receive push notifications</p>
                </div>
                <Switch 
                  checked={notifications.push}
                  onCheckedChange={(checked) => setNotifications(prev => ({...prev, push: checked}))}
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">System Updates</p>
                  <p className="text-sm text-muted-foreground">Receive updates about new features</p>
                </div>
                <Switch 
                  checked={notifications.updates}
                  onCheckedChange={(checked) => setNotifications(prev => ({...prev, updates: checked}))}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Security Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="current-password">Current Password</Label>
                <Input id="current-password" type="password" placeholder="Enter current password" />
              </div>
              <div>
                <Label htmlFor="new-password">New Password</Label>
                <Input id="new-password" type="password" placeholder="Enter new password" />
              </div>
              <div>
                <Label htmlFor="confirm-password">Confirm New Password</Label>
                <Input id="confirm-password" type="password" placeholder="Confirm new password" />
              </div>
              <Button>Update Password</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
