import { Link, useLocation } from "react-router-dom";
import { Button } from "./ui/button";
import { cn } from "../lib/utils";
import { useAuth } from "../contexts/AuthContext";
import {
  LayoutDashboard,
  CalendarCheck,
  CreditCard,
  Bus,
  BookOpen,
  Calendar,
  MessageSquare,
  FileText,
  Library,
  User,
  Menu,
  X,
  LogIn,
  UserPlus,
  LogOut,
  Settings,
  Users,
} from "lucide-react";
import { useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";

const navigationItems = [
  {
    id: "dashboard",
    name: "Dashboard",
    href: "/",
    icon: LayoutDashboard,
    color: "text-primary",
  },
  {
    id: "attendance",
    name: "Attendance",
    href: "/attendance",
    icon: CalendarCheck,
    color: "text-accent",
  },
  {
    id: "students",
    name: "Student Management",
    href: "/students",
    icon: Users,
    color: "text-primary",
  },
  {
    id: "fees",
    name: "Fees & Payments",
    href: "/fees",
    icon: CreditCard,
    color: "text-warning",
  },
  {
    id: "transport",
    name: "Bus Tracker",
    href: "/transport",
    icon: Bus,
    color: "text-info",
  },
  {
    id: "homework",
    name: "Homework",
    href: "/homework",
    icon: BookOpen,
    color: "text-success",
  },
  {
    id: "timetable",
    name: "Timetable",
    href: "/timetable",
    icon: Calendar,
    color: "text-primary",
  },
  {
    id: "communication",
    name: "Notice Board",
    href: "/communication",
    icon: MessageSquare,
    color: "text-accent",
  },
  {
    id: "results",
    name: "Results",
    href: "/results",
    icon: FileText,
    color: "text-info",
  },
  {
    id: "library",
    name: "Library",
    href: "/library",
    icon: Library,
    color: "text-success",
  },
  {
    id: "users",
    name: "User Management",
    href: "/users",
    icon: Settings,
    color: "text-destructive",
  },
  {
    id: "profile",
    name: "Profile",
    href: "/profile",
    icon: User,
    color: "text-warning",
  },
];

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-40">
        <div className="flex items-center justify-between px-4 py-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              className="lg:hidden"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
            <h1 className="text-2xl font-bold text-primary">SchoolHub</h1>
          </div>
          <div className="flex items-center gap-2">
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="h-11 px-2">
                    <Avatar className="h-8 w-8 mr-2">
                      <AvatarImage src={user.profileImage} alt={user.name} />
                      <AvatarFallback>
                        {user.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="text-left">
                      <div className="font-medium text-sm">{user.name}</div>
                      <div className="text-xs text-muted-foreground capitalize">{user.role}</div>
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem asChild>
                    <Link to="/profile">
                      <Settings className="h-4 w-4 mr-2" />
                      Profile Settings
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={logout}>
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <>
                <Button variant="outline" size="sm" className="h-11" asChild>
                  <Link to="/login">
                    <LogIn className="h-4 w-4 mr-2" />
                    Login
                  </Link>
                </Button>
                <Button size="sm" className="h-11" asChild>
                  <Link to="/register">
                    <UserPlus className="h-4 w-4 mr-2" />
                    Register
                  </Link>
                </Button>
              </>
            )}
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={cn(
            "bg-sidebar fixed lg:static inset-y-0 left-0 z-30 w-64 transform transition-transform duration-200 ease-in-out lg:translate-x-0",
            sidebarOpen ? "translate-x-0" : "-translate-x-full"
          )}
        >
          <div className="flex flex-col h-full pt-4">
            <nav className="flex-1 px-4 pt-4 space-y-2">
              {navigationItems.map((item) => {
                const isActive = location.pathname === item.href;
                const Icon = item.icon;
                
                return (
                  <Link
                    key={item.id}
                    to={item.href}
                    onClick={() => setSidebarOpen(false)}
                    className={cn(
                      "flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors hover:bg-sidebar-accent",
                      isActive
                        ? "bg-sidebar-accent text-sidebar-accent-foreground"
                        : "text-sidebar-foreground hover:text-sidebar-accent-foreground"
                    )}
                  >
                    <Icon className={cn("h-5 w-5 flex-shrink-0", isActive ? "text-sidebar-primary" : item.color)} />
                    <span className="truncate">{item.name}</span>
                  </Link>
                );
              })}
            </nav>
            
            <div className="p-4 border-t border-sidebar-border">
              <div className="text-xs text-sidebar-foreground/70">
                © 2024 SchoolHub
              </div>
            </div>
          </div>
        </aside>

        {/* Overlay for mobile */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black/20 z-20 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Main Content */}
        <main className="flex-1 lg:ml-0">
          <div className="p-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
